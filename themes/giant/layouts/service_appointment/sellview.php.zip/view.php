<?php require(base_path().'/themes/giant/header.php'); ?>

<?php 
$currentLocale = app()->getLocale();

if (isset($_GET['page'])){
   echo '';
} 

else{ 
    $lang_code = app()->getLocale();
    $id = pageID();
    $info = \App\Pages::where('id', $id)->first();

    if ($lang_code == 'kh'){

    } else{echo '';}

?>

<style>
    .row.sale-appointment {
        margin-top: 3em;
    }
    img.overview-banner.mobile, .model-cover-mobile, div#overview .mobile, .main-feature2 .mobile, .product-menu .bxs-down-arrow{display: none!important;}
    .model-cover-desktop {
        height: 500px;
        background-size: cover!important;
        background-repeat: no-repeat!important;
        max-width: 1980px;
        margin: 0 auto!important;
    }  
    h2.form-heading-line.second-line {
        font-weight: 600;
        font-size: 18px;
        margin: 25px 15px 25px;
    }
    .sale-appointment .form-group .col-sm-6 {
        margin-bottom: 1.5rem;
    }

    button.btn.btn-default.btn-reg {
        border: 2px solid;
        padding: 15px 65px;
        color: #525252 !important;
        font-weight: 600;
        letter-spacing: 1px;
        background: unset;
        font-size: 16px;
    }
    .col-sm-12.btn-sub {
        text-align: center;
        margin-bottom: 3rem;
        margin-top: 3rem
    }
    select#tycomplaint, select#steam {
        height: auto;
    }
    
    @media screen and (max-device-width: 480px) and (orientation: portrait) {
        
        .row.model-cover-desktop {
            display: none;
        }
        .model-cover-mobile {
            display: block !important;
        }
        h2.form-heading-line.second-line {
            font-weight: 600;
            font-size: 18px;
            margin: 20px 0px 15px;
        }

    }
    
</style>

    <div class="row model-cover-desktop" style="background:url('<?=url('').'/storage/app/uploads/'.$info->header_img?>');"></div>
    <div class="row model-cover-mobile"><img src="<?=url('').'/storage/app/uploads/'.$info->thumbnail?>"/></div>
    

            <div class="row sale-appointment">
                
                <div class="container">
                
                <form name="appointment" action="" method="POST" >

                    <input type="hidden" name="_token" value="<?= csrf_token();?>">
                    <input type="hidden" name="lang" value="<?=$lang?>">
            
                    <h2 class="form-heading-line second-line">Consultant Person</h2>
            
                	<div class="form-group row">
                	    
                		<div class="col-sm-12">
                		    <label  for="tycomplaint" class="col-form-label">Select Consultant Person  <span class="warning">*</span></label>
                            <select class="form-control" name="steam" id="steam">
                                <option value="">Select ...</option>
                                
                                    <?php 
                                        $allsale = get_sale();
                                        foreach($allsale as $val){ 
                                    ?>
                                        <option value="<?php echo $val->name; ?>"> <?php echo $val->name; ?> </option>
                                                
                                    <?php } ?>
                            </select>
                		</div>    	    
                		
                	</div>
            
                	<h2 class="form-heading-line second-line">Model Option</h2>
                	
                    <div class="form-group row">
                        
                        <div class="col-sm-12">
                            
                		    <label  for="tycomplaint" class="col-form-label">Select Model  <span class="warning">*</span></label>
                            <select class="form-control" name="tycomplaint" id="tycomplaint">
                                <option value="">Select Model</option>
                                <option value="Honda CITY RS" >Honda CITY RS</option>
                                <option value="Honda CIVIC" >Honda CIVIC</option>
                                <option value="Honda CR-V" >Honda CR-V</option>
                                <option value="Honda HR-V" >Honda HR-V</option>
                            </select>
            
                        </div> 
            
                    </div>
                    
                    <h2 class="form-heading-line second-line">Customer Information</h2>
                    
                    <div class="from-group row">
                        
                		<div class="col-sm-6">
                		    <label  for="customername" class="col-form-label">Name <span class="warning">*</span></label>
                			<input type="text" name="customername" id="customername" class="form-control" required>
                		</div>
                		
                		<div class="col-sm-6">
                		    <label  for="com_phone" class="col-form-label">Phone Number <span class="warning">*</span></label>
                			<input type="text" name="com_phone" id="com_phone" class="form-control" required>
                		</div>       
                		    
                        <div class="col-sm-6">
            
                            <label  for="date" class="col-form-label">Appointment Date<span class="warning">*</span></label>
                			<input type="date" name="date" id="date" class="form-control">    		    
                		    
                		</div>
                		
                        <div class="col-sm-6">
                            
                		    <label  for="tycomplaint" class="col-form-label">Time <span class="warning">*</span></label>
                            <select class="form-control" name="tycomplaint" id="tycomplaint">
                                <option value="">Select Time</option>
                                <option value="08:00 - 09:30" >08:00AM - 09:30AM</option>
                                <option value="10:00 - 11:30" >10:00AM - 11:30AM</option>
                                <option value="01:00 - 02:30" >01:00PM - 02:30PM</option>
                                <option value="03:00 - 04:30" >03:00PM - 04:30PM</option>
                            </select>
            
                        </div>    
                        
                        <div class="col-sm-12">
                            
                		    <label  for="tycomplaint" class="col-form-label">Location </label>
                            <select class="form-control" name="location" id="tycomplaint">
                                <option value="">Select Location</option>
                                <option value="Showroom" >Showroom</option>
                                <option value="Outdoor" >Outdoor</option>
                            </select>
            
                        </div>              
                        
                    </div>
                    
                	<div class="form-group row">
                		<div class="col-sm-12 btn-sub">
                			<button type="submit" class="btn btn-default btn-reg" name="submit">SUBMIT</button>
                		</div>
                	</div>
                
                </form>
                
                </div>

            </div>

<?php }?>

<?php require(base_path().'/themes/giant/footer.php'); ?>