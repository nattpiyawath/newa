<?php require(base_path().'/themes/giant/header.php'); ?>

<style type="text/css">
    @media screen and (min-width: 1800px) {
        .page-title-area {
            height: 400px;
        }
    }

    .well.well-sm {
        padding: 30px 0;
        padding-right: 15px;
    }

    a.btn.btn-default.btn-sm {
        color: #018142;
        font-size: 28px;
        padding: 0 !important;
    }

    .glyphicon {
        margin-right: 5px;
    }

    .thumbnail {
        margin-bottom: 20px;
        padding: 0px;
        -webkit-border-radius: 0px;
        -moz-border-radius: 0px;
        border-radius: 0px;
    }

    .list-group-item {
        float: none;
        width: 100%;
        background-color: #fff;
        margin-bottom: 10px;
        padding: 0;
        border: none;
    }

    .item.list-group-item:nth-of-type(odd):hover,
    .item.list-group-item:hover {
        background: #428bca;
    }

    .item.list-group-item .list-group-image {
        margin-right: 10px;
    }

    .item.list-group-item .thumbnail {
        margin-bottom: 0px;
    }

    .item.list-group-item .caption {
        padding: 9px 9px 0px 9px;
    }

    .item.list-group-item:nth-of-type(odd) {
        background: #eeeeee;
    }

    .item.list-group-item:before,
    .item.list-group-item:after {
        display: table;
        content: " ";
    }

    .item.list-group-item img {
        float: left;
    }

    .item.list-group-item:after {
        clear: both;
    }

    .list-group-item-text {
        margin: 0 0 11px;
    }

    .row.list-group.grid-group-item {
        flex-direction: inherit;
    }

    .list-group-item .thumbnail img {
        min-width: 50% !important;
    }

    .list-group-item .blog-post-list-thumb {
        height: unset !important;
        background-size: cover;
        min-width: 45%;
    }

    .list-group-item .container.my-2.t1 {
        grid-template-columns: auto !important;
    }

    .list-group-item .card {
        flex-direction: unset;
        margin-bottom: 15px;
    }

    .text-center.pagination {
        justify-content: center;
        padding: 35px 0;
    }

    a.btn-outline.active {
        background: #ee1a29 !important;
        color: #fff;
    }

    a.btn-outline {
        transform: rotate(45deg);
        color: #fff;
        background: #3a3a3a !important;
        border-radius: 0 !important;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px;
        margin: 15px;
        width: 40px;
    }

    a.btn-outline.active:focus {
        display: none;
    }

    a.btn-outline span {
        transform: rotate(-45deg);
    }

    .card.box-promotion i {
        color: #018142;
        font-size: 15px;
        margin-right: 5px;
    }

    .row.list-items {
        margin: 0;
    }

    .side-blog {
        min-width: 110px !important;
        height: 80px !important;
        background-size: cover !important;
        border-radius: 5px;
        margin: 0 8px !important;
    }

    .col-md-12.blogShort {
        display: flex;
        padding: 0;
    }

    .col-md-12.blogShort h4 a {
        font-size: 14px;
        line-height: 20px;
        color: #fff;
    }

    .side-item {
        background: #018142;
        padding: 10px;
        border-radius: 5px;
        margin-top: 50px;
        padding-bottom: 35px !important;
    }

    .side-item h1.amret-home-heading {
        color: #ffffff;
    }

    .side-item p.flex-text.date-time {
        color: #e0e0e0;
    }

    ul.achive-new li {
        border-radius: 5px;
        padding: 8px 20px;
        list-style: none;
        color: #fff;
        border: 1px solid #e0e0e0;
        display: initial;
    }

    p.flex-text.date-time i {
        color: #fccb06;
        margin-right: 5px;
    }

    .card h4.blog-title {
        font-size: 18px;
        font-weight: 600;
        color: #545454;
    }

    .card-body.content-promotion>a svg {
        vertical-align: middle;
        margin-left: 10px;
    }

    .blog-post-list-thumb img {
        width: 75%;
        padding: 15px;
    }

    .blog-post-list-thumb {
        text-align: center;
    }

    .row.list-items .col-md-3.col-sm-6 {
        padding: 0px 15px 20px 0;
    }

    .card.box-spare {
        border-radius: unset;
        filter: drop-shadow(2px 3px 4px #00000020);
    }

    .card.box-spare p {
        font-weight: 500;
        color: #ec1b30;
        margin-bottom: 10px;
    }

    ul.sparts-cate-class li {
        display: inline-flex;
        padding: 0 30px 0 0;
        vertical-align: middle;
    }

    ul.sparts-cate-class li a {
        font-size: 16px;
        font-weight: 500;
        color: #ed1a29;
        text-transform: uppercase;
    }

    ul.sparts-cate-class:after {
        content: "";
        display: block;
        background: #ec1a30;
        height: 3px;
        width: 100%;
        margin: auto;
        margin-top: 10px;
        margin-bottom: 30px;
    }

    ul.sparts-cate-class img {
        max-height: 23px;
        min-width: 23px !important;
        margin-right: 7px;
    }

    .caption.content-blog.box-spare a.url-class:hover {
        color: #ffffff;
        margin-left: 8px;
        transition: all 0.4s cubic-bezier(0.4, 0, 1, 1);
        background: #ec192f;

    }

    .caption.content-blog.box-spare a.url-class {
        color: #4c4c4c;
        font-weight: 600;
        transition: all 0.4s cubic-bezier(0.4, 0, 1, 1);
        background: #00000014;
        padding: 8px 20px;
        border-radius: 50px;
        box-shadow: 0 0 3px #0000001a;

    }
</style>

      <?php

        $lang = app()->getLocale();
        $url = myUpload(); 
        $slug = request()->segment(2);
        if($slug != 'spare-part'){
            $slug = 'spare-part';
        }
        
        $cat = 0;
        $dist = 0;

        if (isset($_GET['sparts_cate'])){
            $dist = $_GET['sparts_cate'];
        }
        
        if (isset($_GET['cat']) && $_GET['cat'] > 0){
            $cat = $_GET['cat'];
            $mers = getFilterSpartCat($cat);
        } else {
            $mers = getSpartCat();
        }
?>
    
<div class="row">
    <div class="col-sm-12" style="padding:0;">
        <div class="details-item">
            <?= $body ?>
        </div>
        <br><br>
        <?php 
$currentLocale = app()->getLocale();

if (isset($_GET['page'])){
   echo '';
} 

else{ 
    $lang_code = app()->getLocale();
    $show_all = 'All';
    $read_more = 'Read More';

    if ($lang_code == 'kh'){
        $show_all = ' បង្ហាញទាំងអស់ ';
        $read_more = ' អានបន្ត';

    } else{echo '';}

?>
<div id="products">


            <div class="container my-2 t1">

                <div class="row">

                    <div class="col-sm-12 be4-merchant">
                        <ul class="sparts-cate-class">

                            <li>

                                <a href="<?php echo URL($lang.'/'.$slug)?>"><?php echo $show_all ;?></a>

                            </li>

                            <?php 
                        $allcat = getSpartCat();
                        foreach($allcat as $val){?>
                            <li <?php if($cat==$val->id){echo 'selected';}?> >

                                <img src="<?php echo $val->thumbnail ;?>" width="20px;"><a
                                    href="<?php echo URL($lang.'/'.$slug).'?cat='.$val->id;?>">
                                    <?=$val->sparts_cate?>
                                </a>

                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>

                <div class="row list-items">

                    <?php
        
        $url = myUpload(); 
        
        foreach ($mers as $val) {
            $cat = $val->id;
            $mers_filter = getAll_Spart_Fitlers($cat);
                        foreach ($mers_filter as $value2){
                    ?>

                    <div class="col-md-3 col-sm-6">

                        <div class="caption content-blog card box-spare fadeinTextup">

                            <div class="card-body content-promotion">
                                <p class="card-text spare-title">
                                    <?=$val->sparts_cate?>
                                </p>
                                <h4 class="blog-title spare-type">
                                    <?php echo $value2->title; ?>
                                </h4>
                                <div class="blog-post-list-thumb"><img
                                        src="<?php echo myUpload().$value2->thumbnail ;?>"></div>

                                <a class="url-class" href="<?php echo URL($lang.'/spart').'/'.$value2->slug;?>"><?php echo $read_more ;?></a>
                            </div>
                        </div>

                    </div>

                    <?php } } ?>

                </div>

            </div>

        </div>

    </div>

</div><br><br>
<?php } ?>    

<?php require(base_path().'/themes/giant/footer.php'); ?>