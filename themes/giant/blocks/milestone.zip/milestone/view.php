<div id="app" class="container">
  <div class="row">

      <div class="col-md-1"><p class="swiper-control prev">
          <button type="button" class="btn btn-default btn-sm prev-slide"><i class="bx bx-chevron-left-square"></i></button>
        </p></div>

    <div class="col-md-10">
    
      <div class="swiper-container">
        
        <div class="swiper-wrapper timeline">


        <?php

$miles = Helper::milestone();
// echo $lang;

foreach ($miles as $value) {?>

<div class="swiper-slide">
            
            <div class="status">
              <div class="timestamp">
                <img src="<?php echo $value->thumbnail;?>"/>
              </div>
             <h1 class="milston-title"><?php echo $value->title ;?></h1>
              <span><?php echo $value->description ;?></span>
            </div>
          </div>

     

<?php  } ?>
        
          
             
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <div class="col-md-1"><p class="swiper-control next">
          <button type="button" class="btn btn-default btn-sm next-slide"><i class="bx bx-chevron-right-square"></i></button>
        </p></div>
  </div>
</div>



<style>
button.btn.btn-default.btn-sm:focus {
    display: none;
}
button.btn.btn-default.btn-sm:active {
  box-shadow: none;
}

button.btn.btn-default.btn-sm {
    background: unset;
    font-size: 30px;
    border: unset;
    padding: 10px 0;
}
#app .col-md-1 .swiper-control {
    text-align: left;
}
.swiper-slide {
    width: 33.333333%!important;
    text-align: center;
}
body {
  background: #e8eeff;
}
#app {
  padding: 15px;
  margin-top: 20px;
}
.timeline {
  list-style-type: none;
  display: flex;
  padding: 0;
  text-align: center;
}
.timeline li {
  transition: all 200ms ease-in;
}
.timestamp {
  display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    font-weight: 100;
    border: 3px solid #018142;
    border-radius: 100%;
    width: 150px;
    height: 150px;
    margin: auto;
    margin-top: 50px;
}
.status {
  padding: 0px 10px;

  justify-content: center;
  border-top: 4px solid #3e70ff;
  position: relative;
  transition: all 200ms ease-in ;
}
.timestamp img {
    width: 100px;
}


.status span:before {
  content: '';
  width: 25px;
  height: 25px;
  background-color: #018142;
  border-radius: 25px;
  border: 6px solid #fff;
  position: absolute;
  top: -15px;
  left: calc(50% - 12px); // align circle to center
  transition: all 200ms ease-in;
}
.swiper-control {
  text-align: right;
}
.timestamp:before {
    content: "";
    height: 50px;
    background: #018142;
    width: 3px;
    display: block;
    position: absolute;
    top: 0px;
    z-index: 1;
}
.swiper-container {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  padding: 0;
}

.swiper-slide:nth-child(2n) {
  width: 40%;
}
.swiper-slide:nth-child(3n) {
  width: 20%;
}
.swiper-slide:nth-child(odd) .status {
    border: 25px solid #018142 !important;
    height: 0px;
}

.swiper-slide:nth-child(even) .status {
    border: 25px solid #8DC63F !important;
    height: 0;
}
button.btn.btn-default.btn-sm.prev-slide {
    float: right;
}
 </style> 
 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/css/swiper.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.3.4/vue.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.min.js"></script>



<script>
const data = [
  { dateLabel: 'January 2017', title: 'Gathering Information' },
  { }
];

new Vue({
  el: '#app', 
  data: {
    steps: data,
  },
  mounted() {
    var swiper = new Swiper('.swiper-container', {
      //pagination: '.swiper-pagination',
      slidesPerView: 3,
      paginationClickable: true,
      grabCursor: true,
      paginationClickable: true,
      nextButton: '.next-slide',
      prevButton: '.prev-slide',
    });    
  }
})
  </script>