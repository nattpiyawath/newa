@extends('template')

@section('title', 'Site Setting Management')

@section('content')

<style type="text/css">
    .width-200{width:216px;}
    nav{max-height: 60px;}
    .panel.panel-default.card-view{max-width: 1000px;}
    .card-view.panel .panel-body{padding: 0;}
    .pagination {margin: 8px 0;}
    .pagination > li.active > a, .pagination > li.active > span {background: #4aa23c;}
    .open>.dropdown-menu {min-width: 228px;}
    .name-default{border: none;text-align: right;}
    .succe_setting{display: none;border: solid 1px #8b9f8a;
    color: #095708;
    max-width: 220px;
    border-radius: 6px;
    padding: 4px 10px;
    text-align: center;
    font-size: 12px;
    margin: 4px 20px;}
</style>

<!-- Title -->
    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 admin-head-title">
            <h5 class="txt-dark"> &nbsp; Site Setting</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                      <ol class="breadcrumb">
                        <li><a href="{{url('admin/dashboard')}}">Dashboard</a></li>
                        <li class="active"><span>Setting</span></li>
        			</ol>
        </div>
        <!-- /Breadcrumb -->
    </div>
<!-- /Title -->

<div class="succe_setting"><i class="fa fa-check" aria-hidden="true"></i> Setting has been updated!</div>

<!-- Row -->
<div class="row">
    <div class="col-sm-12">
        <div class="form-wrap">

                        <form id="update-nav-menu" action="#" method="post" enctype="multipart/form-data">
                            <div class="form-body">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2" style="padding-right: 0;">
                                            <label class="form-control name-default" for="myMenu" style="padding-top: 10px;"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Choose A Header Menu</label>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                            <select class="form-control" id="myMenu">
                                                @if($menus->count())
                                                    @foreach($menus as $value)
                                                        <option <?= $menu_id==$value->id?'selected':''?> value="{{$value->id}}">{{$value->name}}</option>
                                                     @endforeach
                                                @else 
                                                       <option>Menu is Empty</option>   
                                                @endif
                                            </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
    </div>
</div>
<!-- /Row -->

<script type="text/javascript">

    var csrftoken="{{ csrf_token() }}";

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': csrftoken
        }
    });

    $('#myMenu').on('change', function() {
        $('#spincustomu').show();
        var val_id = this.value;
        //alert(menu);
        $.ajax({
            data: {
              value: val_id,
              id:2,
            },
            dataType: 'JSON',
            url: '{{route('updatesetting')}}',
            type: 'POST',
            success: function(response) {
                $('.succe_setting').slideDown('slow');
                setTimeout(function() {
                    $('.succe_setting').slideUp('slow');
                }, 1000);
            }
          });
    });

</script>

@endsection