<?php

if(isset($_GET['page'])){
    
    echo '<h1>Specification Module</h1>';
    
} else{

    $id = pageID();
    $spec = getSpecification($id);
    $lang_code = app()->getLocale();
    if(!empty($spec)){
        foreach ($spec as $value) {
            if($lang_code == 'en'){
            ?>
        
            <div id="specification" class="row container model-spec fadeinTextup">
                <div class="container tap-title-main" >
                    <h1 class="head-titel-page">MODEL SPECIFICATION</h1>
                    
                    <div class="tap-spec">
                        <ul class="nav nav-tabs" role="tablist">
                        	<li class="nav-item">
                        		<a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">ENGINE</a>
                        	</li>
                        	<li class="nav-item">
                        		<a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">DIMENSIONS</a>
                        	</li>
                        	<li class="nav-item">
                        		<a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">SUSPENSION & TIRE</a>
                        	</li>
                        </ul>
                    </div>
                </div>
        
                
                <div class="tab-content">
                	<div class="tab-pane active" id="tabs-1" role="tabpanel">
                		<table style="width:100%" class="table-speci">
                                      <?php if(!empty($value->engine)){?><tr><th>Engine System:</th><td><?php echo $value->engine;?></td></tr><?php }?>
                                      <?php if(!empty($value->bore)){?><tr><th>Bore and Stroke:</th><td><?php echo $value->bore; ?></td></tr><?php }?>
                                      <?php if(!empty($value->displacement)){?><tr><th>Displacement:</th><td><?php echo $value->displacement; ?></td></tr><?php }?>
                                      <?php if(!empty($value->fuel)){?><tr><th>Fuel System:</th><td><?php echo $value->fuel; ?></td></tr><?php }?>
                                      <?php if(!empty($value->feul_type)){?><tr><th>Fuel Type:</th><td><?php echo $value->feul_type; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ignition)){?><tr><th>Ignition System:</th><td><?php echo $value->ignition; ?></td></tr><?php }?>
                                      <?php if(!empty($value->final_drive)){?><tr><th>Final Drive Type:</th><td><?php echo $value->final_drive; ?></td></tr><?php }?>
                                      <?php if(!empty($value->clutch)){?><tr><th>Clutch System:</th><td><?php echo $value->clutch; ?></td></tr><?php }?>
                                      <?php if(!empty($value->starter)){?><tr><th>Starter System:</th><td><?php echo $value->starter; ?></td></tr><?php }?>
                                      <?php if(!empty($value->compression)){?><tr><th>Compression Ratio:</th><td><?php echo $value->compression; ?></td></tr><?php }?>
                                      <?php if(!empty($value->oil_capacity)){?><tr><th>Engine Oil Capacity:</th><td><?php echo $value->oil_capacity; ?></td></tr><?php }?>
                                      <?php if(!empty($value->transmission)){?><tr><th>Transmission:</th><td><?php echo $value->transmission; ?></td></tr><?php }?>
                                      <?php if(!empty($value->oil_replace)){?><tr><th>Oil Replacement:</th><td><?php echo $value->oil_replace; ?></td></tr><?php }?>
                                      <?php if(!empty($value->gearshift)){?><tr><th>Gearshift Pattern:</th><td><?php echo $value->gearshift; ?></td></tr><?php }?>
                                      <?php if(!empty($value->reduction)){?><tr><th>(Primary Reduction/Final Reduction):</th><td><?php echo $value->reduction; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ratio)){?><tr><th>Gear Ratio 1st:</th><td><?php echo $value->ratio; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ratio1)){?><tr><th>Gear radio 2nd:</th><td><?php echo $value->ratio1; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ratio2)){?><tr><th>Gear radio 3rd:</th><td><?php echo $value->ratio2; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ratio3)){?><tr><th>Gear radio 4th:</th><td><?php echo $value->ratio3; ?></td></tr><?php }?>
                        </table>
                	</div>
                	<div class="tab-pane" id="tabs-2" role="tabpanel">
                		<table style="width:100%" class="table-speci">
                                      <?php if(!empty($value->wlh)){?><tr><th>[W X L X H]:</th><td><?php echo $value->wlh; ?></td></tr><?php }?>
                                      <?php if(!empty($value->wheelbase)){?><tr><th>Wheelbase:</th><td><?php echo $value->wheelbase; ?></td></tr><?php }?>
                                      <?php if(!empty($value->weight)){?><tr><th>Weight:</th><td><?php echo $value->weight; ?></td></tr><?php }?>
                                      <?php if(!empty($value->ground)){?><tr><th>Ground Clearance:</th><td><?php echo $value->ground; ?></td></tr><?php }?>
                                      <?php if(!empty($value->seat)){?><tr><th>Seat High:</th><td><?php echo $value->seat; ?></td></tr><?php }?>
                                      <?php if(!empty($value->fuel_tank)){?><tr><th>Fuel Tank:</th><td><?php echo $value->fuel_tank; ?></td></tr><?php }?>
                                      <?php if(!empty($value->caster)){?><tr><th>Caster Angle/Trail:</th><td><?php echo $value->caster; ?></td></tr><?php }?>
                                      <?php if(!empty($value->frame)){?><tr><th>Frame Type:</th><td><?php echo $value->frame; ?></td></tr><?php }?>
                                      <?php if(!empty($value->battery)){?><tr><th>Battery:</th><td><?php echo $value->battery; ?></td></tr><?php }?>
                        </table>
                	</div>
                	<div class="tab-pane" id="tabs-3" role="tabpanel">
                		<table style="width:100%" class="table-speci">
                                      <?php if(!empty($value->tire_front)){?><tr><th>Tire Size Front:</th><td><?php echo $value->tire_front; ?></td></tr><?php }?>
                                      <?php if(!empty($value->tire_rear)){?><tr><th>Tire Size Rear:</th><td><?php echo $value->tire_rear; ?></td></tr><?php }?>
                                      <?php if(!empty($value->front_brake)){?><tr><th>Front Brake:</th><td><?php echo $value->front_brake; ?></td></tr><?php }?>
                                      <?php if(!empty($value->rear_brake)){?><tr><th>Rear Brake:</th><td><?php echo $value->rear_brake; ?></td></tr><?php }?>
                                      <?php if(!empty($value->tire_type)){?><tr><th>Tire Type:</th><td><?php echo $value->tire_type; ?></td></tr><?php }?>
                                      <?php if(!empty($value->suspension)){?><tr><th>Suspension Front:</th><td><?php echo $value->suspension; ?></td></tr><?php }?>
                                      <?php if(!empty($value->suspension_rear)){?><tr><th>Suspension Rear:</th><td><?php echo $value->suspension_rear; ?></td></tr><?php }?>
                        </table>
                	</div>
                </div>
            </div>
                
            <?php } else {?>  
 
            <div id="specification" class="row container model-spec fadeinTextup">
                <div class="container tap-title-main" >
                    <h1 class="head-titel-page">ព័ត៌មានបច្ចេកទេស</h1>
                    
                    <div class="tap-spec">
                        <ul class="nav nav-tabs" role="tablist">
                        	<li class="nav-item">
                        		<a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">ម៉ាស៊ីន</a>
                        	</li>
                        	<li class="nav-item">
                        		<a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab"> វិមាត្រ </a>
                        	</li>
                        	<li class="nav-item">
                        		<a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab"> ប្រព័ន្ធបូម និងសំបកកង់ </a>
                        	</li>
                        </ul>
                    </div>
                </div>
        
                
                <div class="tab-content">
                	<div class="tab-pane active" id="tabs-1" role="tabpanel">
                                        <table style="width:100%" class="table-speci">
                                          <?php if(!empty($value->engine)){?><tr><th>ប្រភេទម៉ាស៊ីន៖  </th><td><?php echo $value->engine; ?></td></tr><?php }?>
                                          <?php if(!empty($value->bore)){?><tr><th> អង្កត់ផ្ចិត និងចំងាយចរពិស្តុង៖  </th><td><?php echo $value->bore; ?></td></tr><?php }?>
                                          <?php if(!empty($value->displacement)){?><tr><th>  ទំហំមាឌស៊ីឡាំង៖  </th><td><?php echo $value->displacement; ?></td></tr><?php }?>
                                          <?php if(!empty($value->fuel)){?><tr><th>  ប្រព័ន្ធប្រេង៖  </th><td><?php echo $value->fuel; ?></td></tr><?php }?>
                                          <?php if(!empty($value->feul_type)){?><tr><th>  ប្រភេទប្រេងឥន្ធនៈ៖  </th><td><?php echo $value->feul_type; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ignition)){?><tr><th>  ប្រព័ន្ធចំហេះ៖  </th><td><?php echo $value->ignition; ?></td></tr><?php }?>
                                          <?php if(!empty($value->final_drive)){?><tr><th>  ប្រព័ន្ទបញ្ចូលចលនាចុងក្រោយ៖  </th><td><?php echo $value->final_drive; ?></td></tr><?php }?>
                                          <?php if(!empty($value->clutch)){?><tr><th> ប្រព័ន្ធលេខ៖  </th><td><?php echo $value->clutch; ?></td></tr><?php }?>
                                          <?php if(!empty($value->starter)){?><tr><th> ប្រព័ន្ធបញ្ឆេះម៉ាស៊ីន៖  </th><td><?php echo $value->starter; ?></td></tr><?php }?>
                                          <?php if(!empty($value->compression)){?><tr><th> កម្រិតបង្ហាប់៖ </th><td><?php echo $value->compression; ?></td></tr><?php }?>
                                          <?php if(!empty($value->oil_capacity)){?><tr><th> ចំណុះប្រេងម៉ាស៊ីន៖ </th><td><?php echo $value->oil_capacity; ?></td></tr><?php }?>
                                          <?php if(!empty($value->transmission)){?><tr><th>  ប្រព័ន្ធលេខ៖  </th><td><?php echo $value->transmission; ?></td></tr><?php }?>
                                          <?php if(!empty($value->oil_replace)){?><tr><th>  រយៈពេលដែលត្រូវប្តូរប្រេងម៉ាស៊ីន៖  </th><td><?php echo $value->oil_replace; ?></td></tr><?php }?>
                                          <?php if(!empty($value->gearshift)){?><tr><th>  ប្រព័ន្ធបញ្ចូលចលនា (ចង្កឹះលេខ៖)  </th><td><?php echo $value->gearshift; ?></td></tr><?php }?>
                                          <?php if(!empty($value->reduction)){?><tr><th>  ផលធៀបពីញ៉ុងងឺ/ផលធៀបច្រវាក់ពីញ៉ុង៖ </th><td><?php echo $value->reduction; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ratio)){?><tr><th>  ផលធៀបពីញ៉ុងលេខ : លេខ 1៖  </th><td><?php echo $value->ratio; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ratio1)){?><tr><th>  ផលធៀបពីញ៉ុងលេខ : លេខ 2៖  </th><td><?php echo $value->ratio1; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ratio2)){?><tr><th>  ផលធៀបពីញ៉ុងលេខ : លេខ 3៖  </th><td><?php echo $value->ratio2; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ratio3)){?><tr><th>  ផលធៀបពីញ៉ុងលេខ : លេខ 4៖  </th><td><?php echo $value->ratio3; ?></td></tr><?php }?>
                                        </table>
                	</div>
                	<div class="tab-pane" id="tabs-2" role="tabpanel">
                                      <table style="width:100%" class="table-speci">
                                          
                                          <?php if(!empty($value->wlh)){?><tr><th>បណ្តោយ x ទទឹង x កំពស់៖  </th><td><?php echo $value->wlh; ?></td></tr><?php }?>
                                          <?php if(!empty($value->wheelbase)){?><tr><th> ប្រវែងពីកង់មុខទៅកង់ក្រោយ៖  </th><td><?php echo $value->wheelbase; ?></td></tr><?php }?>
                                          <?php if(!empty($value->weight)){?><tr><th>  ទម្ងន់៖  </th><td><?php echo $value->weight; ?></td></tr><?php }?>
                                          <?php if(!empty($value->ground)){?><tr><th>  គំលាតពីដី៖  </th><td><?php echo $value->ground; ?></td></tr><?php }?>
                                          <?php if(!empty($value->seat)){?><tr><th>  កម្ពស់កែប៖  </th><td><?php echo $value->seat; ?></td></tr><?php }?>
                                          <?php if(!empty($value->fuel_tank)){?><tr><th>  ចំណុះធុងសាំង៖  </th><td><?php echo $value->fuel_tank; ?></td></tr><?php }?>
                                          <?php if(!empty($value->caster)){?><tr><th>  មុំទម្រេតជំពាស់មុខ៖  </th><td><?php echo $value->caster; ?></td></tr><?php }?>
                                          <?php if(!empty($value->frame)){?><tr><th> តួម៉ូតូ៖  </th><td><?php echo $value->frame; ?></td></tr><?php }?>
                                          <?php if(!empty($value->battery)){?><tr><th> អាគុយ៖  </th><td><?php echo $value->battery; ?></td></tr><?php }?>

                                        </table>
                	</div>
                	<div class="tab-pane" id="tabs-3" role="tabpanel">
                                      <table style="width:100%" class="table-speci">
                                          
                                          <?php if(!empty($value->tire_front)){?><tr><th> ទំហំសំបកកង់ (មុខ)៖ </th><td><?php echo $value->tire_front; ?></td></tr><?php }?>
                                          <?php if(!empty($value->tire_rear)){?><tr><th> ទំហំសំបកកង់ (ក្រោយ)៖  </th><td><?php echo $value->tire_rear; ?></td></tr><?php }?>
                                          <?php if(!empty($value->front_brake)){?><tr><th>  ប្រព័ន្ធហ្វ្រាំង (មុខ)៖   </th><td><?php echo $value->front_brake; ?></td></tr><?php }?>
                                          <?php if(!empty($value->rear_brake)){?><tr><th>  ប្រព័ន្ធហ្រ្វាំង (ក្រោយ)៖  </th><td><?php echo $value->rear_brake; ?></td></tr><?php }?>
                                          <?php if(!empty($value->tire_type)){?><tr><th>  ប្រព័ន្ធកង់  </th><td><?php echo $value->tire_type; ?></td></tr><?php }?>
                                          <?php if(!empty($value->suspension)){?><tr><th>  ប្រព័ន្ធបូមមុខ៖  </th><td><?php echo $value->suspension; ?></td></tr><?php }?>
                                          <?php if(!empty($value->suspension_rear)){?><tr><th>  ប្រព័ន្ធបូមក្រោយ៖  </th><td><?php echo $value->suspension_rear; ?></td></tr><?php }?>                                          
                                          
                                        </table>
                	</div>
                </div>
            </div> 
                
            <?php }
        } 
    } else{echo '<h3>Empty Specification!</h3>';}
    
}?>