@extends('template')

@section('title', 'Edit Gallery - '.$gallery->gallery_name)

@section('content')

@php
$lang = 'en';
if(isset($_GET['lang'])){
    $lang = $_GET['lang'];
}
@endphp

@php
$myStorage = '/storage/app/uploads/';
@endphp



<style type="text/css">
    textarea.form-control {height: 80px;}
    .card-view {max-width: 1280px;margin: 0 auto;}
    button#addMore {
    right: 0;
    margin-top: -36px;
    float: right;
    position: absolute;
    margin-right: 16px;
  }
  .close-x{display: flex;}
</style>

<div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default card-view">
                                <div class="panel-heading">
                                    <div class="pull-left">
                                        <h6 class="panel-title txt-dark">Edit - {{$gallery->gallery_name}}</h6>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="form-wrap">

                                                   {!! Form::open(['route' => ['gallery.update', $gallery->id], 'method' => 'PATCh']) !!}

                                                        <input type="hidden" name="lang_code" value="{{$lang}}">
                                                        
                                                        <div class="form-body">

                                                            <div class="row">
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <label for="page-status">Status</label>
                                                                        <select class="form-control" data-placeholder="Status" name="is_published">
                                                                            @php 
                                                                                $status = $gallery->is_published;
                                                                            @endphp

                                                                            @if ($status == 1)
                                                                                <option value="1" selected>Publish</option>
                                                                                <option value="0">Draft</option>
                                                                            @else
                                                                                <option value="0" selected>Draft</option>
                                                                                <option value="1">Publish</option>
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3"> 
                                                                    <div class="form-group">
                                                                    <label for="select-country">Translate Of </label>

                                                        <select class="form-control selectpicker" id="select-page" data-live-search="true" name="translate_id">

                                                            <option value="0">Select...</option>
                                                                    @foreach($gallery_lang as $pg)
                                                                    <option <?= $gallery->translate_id==$pg->translate_id?'selected':''?> data-tokens="{{$pg->gallery_name}}" value="{{$pg->translate_id}}">{{$pg->gallery_name}}</option>
                                                                    @endforeach

                                                              </select> 
                                                                    </div>
                                                                </div>

                                                                
                                                                <!--/span-->
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <div class="form-actions mt-10" style="text-align: right;">
                                                                        <a class="btn btn-default btn-close" href="{{url('admin/gallery?lang='.$lang)}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back</a>
                                                                        {{ Form::button('<i class="fa fa-floppy-o" aria-hidden="true"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success mr-10'] )  }}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!--/span-->
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group @if($errors->has('gallery_name')) has-error @endif">
                                                                        <label class="control-label mb-10">GAllery Name</label>

                                                                        {!! Form::text('gallery_name', $gallery->gallery_name, ['class' => 'form-control', 'placeholder' => 'Enter name here']) !!}
                                                                        @if ($errors->has('gallery_name'))
                                                                            <span class="help-block">{!! $errors->first('gallery_name') !!}</span>
                                                                        @endif

                                                                    </div>
                                                                </div>

                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label class="control-label mb-10">Added Gallery For</label>
                                                                        <select class="form-control selectpicker" data-live-search="true" data-placeholder="Choose a Post" name="page_id">
                                                                            <option value="0">Select...</option>
                                                                            @foreach($pages as $val)
                                                                                <option <?php if($gallery->page_id == $val->id){echo 'selected';}?> value="{{$val->id}}">{{$val->title}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                                
                                                            </div>


                                                            </div>

                                                            <div id="addRow">
                                                            
                                                            <?php if(!empty($gallery->data)){
                                                              
                                                              foreach(json_decode($gallery->data) as $index => $val){

                                                              ?>

                                                              @if($index == 0)

                                                              <div class="row delete_add_more_item" id="delete_add_more_item">
                                                                  <div class="col-md-3">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_url[]" value="{{$val->image_url}}" placeholder="Enter URL" />

                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-3">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_title[]" value="{{$val->image_title}}" placeholder="Enter Title" />
                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-4">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_caption[]" value="{{ $val->image_caption}}" placeholder="Enter Caption" />
                                                                      </div>
                                                                  </div>
                                                                  <div class="col-md-2">
                                                                      <div class="form-group">
                                                                      </div>
                                                                  </div>
                                                                </div>

                                                                @else

                                                                <div class="row delete_add_more_item" id="delete_add_more_item">
                                                                  <div class="col-md-3">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_url[]" value="{{$val->image_url}}" placeholder="Enter URL" />

                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-3">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_title[]" value="{{$val->image_title}}" placeholder="Enter Title" />
                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-4">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_caption[]" value="{{ $val->image_caption}}" placeholder="Enter Caption" />
                                                                      </div>
                                                                  </div>
                                                                  <div class="col-md-2">
                                                                      <div class="form-group">
                                                                            <div class="form-group close-x">
                                                                              <span class="removeaddmore" style="cursor:pointer;color:red;padding: 4px 10px;border-radius: 90%;border: solid 1px;"><i class="fa fa-times" aria-hidden="true"></i><span>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                </div>

                                                                @endif
                                                            
                                                              <?php } } ?>

                                                            </div>

                                                    {!! Form::close() !!}

                                                     <button id="addMore" class="btn btn-success btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>      
                        </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.6/handlebars.min.js"></script> 

<script id="document-template" type="text/x-handlebars-template">
<div class="row delete_add_more_item" id="delete_add_more_item">
  <div class="col-md-3">
    <div class="form-group">
        <input type="text" class="form-control" name="image_url[]" placeholder="Enter URL" value="@{{ image_url }}">
    </div>
  </div>

  <div class="col-md-3">
    <div class="form-group">
        <input type="text" class="form-control" name="image_title[]" placeholder="Enter Title" value="@{{ image_title }}">
    </div>
  </div>

  <div class="col-md-4">
    <div class="form-group">
        <input type="text" class="form-control" name="image_caption[]" placeholder="Enter Caption" value="@{{ image_caption }}"> 
    </div>
  </div>

  <div class="col-md-2">
    <div class="form-group close-x">
        <span class="removeaddmore" style="cursor:pointer;color:red;padding: 4px 10px;border-radius: 90%;border: solid 1px;"><i class="fa fa-times" aria-hidden="true"></i><span>
    </div>
  </div>
</div>
 </script>

 <script type="text/javascript">

  $(function() {
    $('.selectpicker').selectpicker();
  });

</script>


<script type="text/javascript">
 
 $(document).on('click','#addMore',function(){

     var image_url = $("#image_url").val();
     var image_title = $("#image_title").val();
     var image_caption = $("#image_caption").val();
     var source = $("#document-template").html();
     var template = Handlebars.compile(source);

     var data = {
        image_url: image_url,
        image_title: image_title,
        image_caption: image_caption
     }

     var html = template(data);
     $("#addRow").append(html)
 });

  $(document).on('click','.removeaddmore',function(event){
    $(this).closest('.delete_add_more_item').remove();
  });
                    
</script>

@endsection