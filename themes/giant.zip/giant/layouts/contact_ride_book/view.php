<?php require(base_path().'/themes/giant/header.php'); ?>

<style type="text/css">

    .contact-form label {
        color: #000;
        margin-bottom: 5px;
        font-size: 14px;
    }
    .each-row {
        margin: 0px 0 20px;
    }
    a.btn-submit {
        border: 2px solid;
        padding: 10px 25px;
        color: #525252 !important;
        font-weight: 600;
        letter-spacing: 1px;
    }
    .fomr-contactus {
        margin-bottom: 50px;
        padding-right: 40px;
    }
    .under-contact .social li.ico {
        display: inline-block;
        border: 1px solid #008348;
        border-radius: 35px;
        padding: 10px;
        margin-top: -5px;
        margin-bottom: 15px;
    }
    .under-contact li i.bx {
        color: #008348;
        font-size: 15px;
    }
    .left-of-contact {
        border: 1px solid #ffffff87;
        height: max-content;
        top: 55px;
        margin-bottom: 110px;
        padding: 15px !important;
        background:#F2F2F2;
        box-shadow:none !important;
    }
    .col-sm-10.detail-con {
        padding: unset;
    }
	.cover-page.cover-iagme-about-page {
        background-repeat: no-repeat !important;
        background-size: cover !important;
        height: auto;
        background-position: center center !important;
    }
    
    h1.head-title-contant {
        font-size: 22px;
        color: #3a3a3a;
        margin-top: 60px;
        margin-bottom: 40px;
        padding:0 15px;
    }
    .form-control {
        background: #f9f9f9;
        border: unset;
        border-radius: 0;
        filter: drop-shadow(2px 2px 4px #00000020);
        padding: 15px;
    }
    .text-right {
        margin-top: 20px;
    }
    h1.mroe-detail-title {
        font-size: 20px;
        color: rgb(58 58 58);
        margin-bottom: 15px!important;
        margin-top: 20px;
    }
    .left-of-contact svg {
        width: 15px !important;
        margin-right: 10px;
        vertical-align: middle;
        fill: #3a3a3a !important;
    }
    select.mdb-select.md-form {
        padding: 15px;
        border: 0 !important;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100' fill='%717171'><polygon points='0,0 100,0 50,50'/></svg>") no-repeat;
        background-size: 12px;
        background-position: calc(100% - 15px) 22px;
        background-repeat: no-repeat;
        background-color: #f9f9f9;
        width: 100%;
        filter: drop-shadow(rgba(0, 0, 0, 0.125) 2px 2px 4px);
        color: #6f777f;
    }
    </style>

<?php if(isset($_GET['page'])): ?>

<div class="page-title-area title-bg-one">
   <div class="title-shape">
      <div class="cover-page cover-iagme-about-page" style="background:url(<?= myUpload().getImageheader($lang);?>);">
   <div class="d-table">
      <div class="d-table-cell">
         <div class="container">
            <div class="title-content">
               <h2><?php echo pageTitle();?></h2>
               
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>
<?php else: ?>

<div class="page-title-area title-bg-one">
   <div class="title-shape">
      <div class="cover-page cover-iagme-about-page" style="background:url(<?= myUpload().getImageheader($lang);?>);">
   <div class="d-table">
      <div class="d-table-cell">
         <div class="container">
            <div class="title-content">
               <h2><?php echo pageTitle();?></h2>
              
            </div>
         </div>
      </div>
   </div>
</div></div></div>
<?php endif; ?>

<div class="container">

<div class="row">

        <!--Grid column-->
        <div class="col-md-9 fomr-contactus">
            
            <h1 class="head-title-contant">Please fill in the information Below to complete</h1>
            
            <form id="contact-form" name="contact-form" action="mail.php" method="POST">

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-6 each-row">
                        <div class="contact-form">
                            
                            <input type="text" id="name" name="name" class="form-control" placeholder='Your name'>
                            
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-6 each-row">
                        <div class="contact-form">
                            <input type="email" id="number" name="number" class="form-control" placeholder="Email">
                            
                        </div>
                    </div>
                    <!--Grid column-->
                    <div class="col-md-12 each-row">
                        <div class="contact-form">
                            
                            <input type="tel" id="number" name="number" class="form-control" placeholder='Phone Number'>
                            
                        </div>
                    </div>
                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">
                    <div class="col-md-12 each-row">
                        <div class="contact-form">
                            
                            <input type="text" id="subject" name="subject" class="form-control" placeholder='Address'>
                             
                        </div>
                    </div>
                </div>
                <!--Grid row-->

                <!--Grid row-->
                  <h1 class="head-title-contant" style="margin-top:30px;">Select Model and Showroom</h1>
                    <div class="row">
                    <div class="col-md-6 each-row">
                        <div class="contact-form">
                        <select class="mdb-select md-form" searchable="Search here..">
                            <option value="" disabled selected>Select Model</option>
                            <option value="1">USA</option>
                            <option value="2">Germany</option>
                            <option value="3">France</option>
                            <option value="3">Poland</option>
                            <option value="3">Japan</option>
                      </select>
                        </div>
                    </div>
                     <div class="col-md-6 each-row">
                        <div class="contact-form">
                         <select class="mdb-select md-form" searchable="Search here..">
                            <option value="" disabled selected>Choose Showroom</option>
                            <option value="1">USA</option>
                            <option value="2">Germany</option>
                            <option value="3">France</option>
                            <option value="3">Poland</option>
                            <option value="3">Japan</option>
                      </select>
                        </div>
                    </div>
                </div>
                
                 <div class="row">
                <div class="col-md-12 each-row">
                	<div class="input-group registration-date-time">
            		<span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span></span>
            		<input class="form-control" name="registration_date" id="registration-date" type="date" searchable="Date for Test Drive">
            	 </div>	
            	 </div>
                </div>
                
                
                <div class="text-right">
                    <a class="btn-submit" onclick="document.getElementById('contact-form').submit();">SUBMIT</a>
                </div>
            
            </form>

          
            
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-3 left-of-contact">

            <?= $body ?>
    
        </div>
        <!--Grid column-->

    </div>

</div>   

<script>
$(document).ready(function() {
$('.mdb-select').materialSelect();
});
</script>

<?php require(base_path().'/themes/giant/footer.php'); ?>