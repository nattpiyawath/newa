<?php require(base_path().'/themes/giant/header.php'); ?>
<style type="text/css">
	@media screen and (min-width: 1800px){
		.page-title-area {height: 400px;}
	}
	.wrapper {text-align: center;color: #444;}
    #threesixty {margin: 0 auto;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;}
    .g-hub {color: #444;font-size: 0.9em;}
    .buttons-wrapper {max-width: 200px;width: 100%;margin: 0 auto;display: flex;justify-content: space-between;}
    .button {
      position: relative;
      -webkit-appearance: none;
         -moz-appearance: none;
              appearance: none;
      border: none;
      padding: 40px 7px 5px;
      cursor: pointer;
    }
    .button::before, .button::after {
      content: "";
      position: absolute;
      top: 10px;
      left: 50%;
      border-left: 3px solid #000;
      border-top: 3px solid #000;
      width: 20px;
      height: 20px;
      transform: translate(-45%) rotate(-45deg);
    }
    .button::after {transform: translate(5%) rotate(-45deg);}
    #next::before {transform: translate(-90%) rotate(135deg);}
    #next::after {transform: translate(-50%) rotate(135deg);}
    .image-360:hover{cursor: pointer;}
    .select-color input[type="button"] {border: none;width: 45px;height: 45px;transform: rotate(45deg);margin-right: 30px;}
    .main {font-family:Arial;width:600px;display:block;margin:0 auto;}
    .action{display:block;margin:100px auto;width:100%;text-align:center;}
    .action a {display:inline-block;padding:5px 10px; background:#f30;color:#fff;text-decoration:none;}
    .action a:hover{background:#000;}
    .slick-slide{height: auto!important;}
    .slider-nav .slick-current > div img {border-top: 3px solid #e21428;}
    .content-img-360{max-width:25%;}
    .product-menu h1 {font-size: 22px;font-weight: 600;position: relative;margin-bottom: 0px !important;padding: 13px 15px 13px;}
    .product-menu.main-nav ul li a {position: relative !important;color: #22262a;}
    .product-menu.main-nav ul li a:hover{color: #22262a !important;}
    .product-menu.main-nav.menu-shrink {position: fixed;top: 60px;transition: auto !important;text-align: left!important;}
    .row.flex-detai-gallery {display: inline-flex!important;align-items: center;}
    .slick-slide img{width: 100%;max-width: 100% !important;}
    .slick-current > div {border: none!important;}
    .big-cover-slide {background: #efefef;}
    .slider.slider-nav.slick-slider {margin-top: 15px;}
    .slider.slider-nav.slick-slider img {width: 95%;}
    .slick-next:before{
        content: "\ec8f"!important;
        font-family: 'boxicons'!important;
        color: #ffffff !important;
        background: #ec1b30;
        padding: 10px;
    }
       .slick-prev:before {
        content: "\ec8c" !important;
        font-family: 'boxicons' !important;
        color: #ffffff !important;
        background: #ec1b30;
        padding: 10px;
    }
    .slick-prev{left: -60px!important;}
    table.table-speci th {
        font-weight: 600;
        line-height: 32px;
    }
    table.table-speci tr:last-child {
        border-bottom: unset !important;
    }
    table.table-speci tr {
        border-bottom: 1px solid #ccccccc7;
        position: relative;
        height: 50px;
    }
    .product-menu.main-nav.menu-shrink .navbar-light {
        transition: 0.4s;
    }
    .product-menu.main-nav.menu-shrink h1 {
        font-size: 22px;
        padding: 13px 5px !important;
    }
    .feature-product {
        height: 100vh;
        align-items: center;
        text-align: center;
    }
    .product-nav-bar {
        justify-content:unset!important;
        display:flex;
    }
    
    .smart-feature a.btn:hover {
    background-position: 0 0;
    color: #ffffff;
    border-color: #ffffff;
}
.smart-feature a.btn {
    background-image: linear-gradient(to left, transparent, transparent 50%, #d43131 50%, #1d0707);
    background-position: 100% 0;
    background-size: 200% 100%;
    transition: all .25s ease-in;
}
h5.model-no {
    color: #4d4d4d;
    font-size: 18px;
    margin-top:20px;
}
.product-nav-bar li:hover a, .product-nav-bar li a:hover{color:#fff!important;}

@media screen and (max-width:414px){
    .main-nav nav .navbar-nav .nav-item{padding: 6px 8px!important;}
    .all-lang-2.newClass {position: absolute;}
    .product-menu.main-nav ul li a{top:0;width: max-content;float: left;overflow: hidden;}
    .slide-caption{position:unset;}
    .slide-caption p {font-size: 15px;margin-top: 0;line-height: 20px;padding: 10px;}
    .flex-detai-gallery .slide-caption h1 {font-size: 20px;line-height:25px;}

    
}

</style>

<!-- Navbar Product View -->

<?php 
$currentLocale = app()->getLocale();


    $lang_code = app()->getLocale();
    $sel_color = 'SELECT YOUR COLOR';
  
    if ($lang_code == 'kh'){
        $sel_color = 'ជំរើសពណ៌';
    } else{echo '';}

?>

    <?php 
    $page_type = getPageType();
    //echo $page_type;
    if($page_type == 'product'){?>
        <div class="product-menu main-nav">
            <div class="container">
                <?php 
    
                    $lang_code = app()->getLocale();
                    
                    if($lang_code == 'en'){
                ?>
                
                <div class="row">
                    <div class="col-sm-4">
                        <h1><?=pageTitle();?></h1>
                    </div>
                    <div class="col-sm-7">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <ul class="product-nav-bar">
                                <li class="nav-item active"><a href="#overview">OVERVIEW</a></li>
                                <li class="nav-item"><a href="#main-feature1">MAIN FEATURES</a></li>
                                <!--<li class="nav-item" id="view-full-degree">360 VIEW</li>-->
                                <li class="nav-item"><a href="#other-feature">OTHER FEATURES</a></li>
                                <li class="nav-item"><a href="#smart-feature">COLORS</a></li>
                                <li class="nav-item"><a href="#specification">SPECIFICATIONS</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-sm-1"></div>
                </div> 
                
                
             <?php } else {?>  
            
                <div class="row">
                    <div class="col-sm-4">
                        <h1><?=pageTitle();?></h1>
                    </div>
                    <div class="col-sm-7">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <ul class="product-nav-bar">
                                <li class="nav-item active"><a href="#overview">  ទិដ្ឋភាពទូទៅ  </a></li>
                                <li class="nav-item"><a href="#main-feature1">  លក្ខណៈពិសេស  </a></li>
                                <!--<li class="nav-item" id="view-full-degree">360 VIEW</li>-->
                                <li class="nav-item"><a href="#other-feature">  លក្ខណៈពិសេសផ្សេងទៀត </a></li>
                                <li class="nav-item"><a href="#smart-feature">  ពណ៌   </a></li>
                                <li class="nav-item"><a href="#specification">  ព័ត៌មានបច្ចេកទេស  </a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-sm-1"></div>
                </div> 
            
            <?php } ?>  
                
                
            </div>
        </div>
    <?php }?>
    
    <!-- End Navbar Product View -->

<script src="https://cdn.jsdelivr.net/npm/@mladenilic/threesixty.js/dist/threesixty.js"></script>

<?= $body ?>

<?php if(!isset($_GET['page'])){?>

    <!-- Model 360 View -->
    <style>
        .content-img-360{display:none;}
    </style>
    
    <!-- End Model Slideshow-->
    
    

    <!-- Model Colour -->
    
     <div class="color-finding-love">
        <div class="container">
            <div class="row select-model-color">
                <div class="col-md-6 model-color-left" >
                    <br><br>
                    
                    <div class="select-color">
                        <h5><?php echo $sel_color?></h5><br>
                            <?php
                                $lang_code = app()->getLocale();
                                $id = pageID();
                                //echo $id;
                                $getColor = getColor($id);
                                //print_r($gall);
                                
                                if(!empty($getColor)){ 
                                    $colour = collect(json_decode($getColor))->sortByDesc('color_order')->reverse()->toArray();
                                    foreach($colour as $index => $val){ ?>  
                                    <input type="button" <?php if($val->color_order == 1){echo 'class="primary-color"';}?> data-url="<?=myUpload().$val->image_url;?>" 
                                    data-related-color="<?=$val->related_color;?>" data-color-code="<?=$val->color_code;?>" style="background:<?=$val->color_code;?>;"/>
                                <?php }
                                } else{echo 'No Color to Show!';}
                            ?>
                    </div>
                </div>
                <div class="col-md-6 model-color-right">
                    <div class="preview-color fadeinTextup">
                        <img id="my-image-preview" class="" src="#"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        $('.select-color input').on('click', function(){
           var img = $(this).attr('data-url');
           var color_code = $(this).attr('data-color-code');
           var related_color = $(this).attr('data-related-color');
           var background = 'linear-gradient(to right, '+related_color+' , '+color_code+')';
           $('.smart-feature').css('background-image', background);
           $('#my-image-preview').attr('src', img);
            
        });
        
        $(".select-color input").click(function()  {
            var clickedButton = $('#my-image-preview');
            var clickedButton1 = $('.preview-color');
            if (clickedButton.hasClass('active')) {
                $('#my-image-preview').removeClass('active');
                $('.preview-color').addClass('active1').load();
                return false;
            }
            clickedButton.addClass('active').load();
            clickedButton1.removeClass('active1').load();
        });

        
        var primary = $('.primary-color').attr('data-color-code');
        var primary2 = $('.primary-color').attr('data-related-color');
        var background2 = 'linear-gradient(to right, '+primary2+' , '+primary+')';
        $('.smart-feature').css('background-image', background2);
        
        var image2 = $('.primary-color').attr('data-url');
        $('#my-image-preview').attr('src', image2);
        
        
        
        $(window).scroll(function() {
		var windscroll = $(window).scrollTop();
		if (windscroll >= 0) {
			$('.sectionscroll').each(function(i) {
        // The number at the end of the next line is how pany pixels you from the top you want it to activate.
				if ($(this).position().top <= windscroll + 100) {
					$('.product-nav-bar li.active').removeClass('active');
					$('.product-nav-bar li').eq(i).addClass('active');
				}
			});

		} else {

			$('.product-nav-bar li.active').removeClass('active');
			$('.product-nav-bar li:first').addClass('active');
		}

		}).scroll();
		
    </script>
    
    <!-- end moduel color -->
    
    <?php

    $id = pageID();
    $spec = getSpecification($id);
    $lang_code = app()->getLocale();
    
    foreach ($spec as $value) {?>
    
    <!-- Model Spec -->

        
            <?php 

                $lang_code = app()->getLocale();
                
                if($lang_code == 'en'){
            ?>

    <div class="row model-spec specification fadeinTextup sectionscroll">
        <div class="container" >
            <h1 class="head-titel-page"><?=pageTitle();?> SPECIFICATION</h1>
        </div>

        <div class="col-md-12">
            <div class="container my-4">

                <h5 class="model-no">
                            <B>MODEL CODE: </B> <?php echo $value->code; ?>
                          </h5>
                  <!--Accordion wrapper-->
                  <br>
                  <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
              
                    <!-- Accordion card -->
                
                    <!-- Accordion card -->
                    <div class="card fadeinTextup">
                
                      <!-- Card header -->
                      <div class="card-header" role="tab" id="headingTwo2">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                          <h5 class="mb-0">
                            ENINGE <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseTwo2" class="collapse" role="tabpanel" aria-labelledby="headingTwo2" data-parent="#accordionEx">
                        <div class="card-body">
                            <table style="width:100%" class="table-speci">
                              <tr>
                                <th>Engine System</th>
                                <td><?php echo $value->engine; ?></td>
                              </tr>
                              <tr>
                                <th>Bore and Stroke</th>
                                <td><?php echo $value->bore; ?></td>
                              </tr>
                              <tr>
                                <th>Displacement</th>
                                <td><?php echo $value->displacement; ?></td>
                              </tr>
                              <tr>
                                <th>Fuel System</th>
                                <td><?php echo $value->fuel; ?></td>
                              </tr>
                              <tr>
                                <th>Fuel Type</th>
                                <td><?php echo $value->feul_type; ?></td>
                              </tr>
                              <tr>
                                <th>Ignition System</th>
                                <td><?php echo $value->ignition; ?></td>
                              </tr>
                              <tr>
                                <th>Final Drive Type</th>
                                <td><?php echo $value->final_drive; ?></td>
                              </tr>
                              <tr>
                                <th>Clutch System</th>
                                <td><?php echo $value->clutch; ?></td>
                              </tr>
                              <tr>
                                <th>Starter System</th>
                                <td><?php echo $value->starter; ?></td>
                              </tr>
                              <tr>
                                <th>Compression Ratio</th>
                                <td><?php echo $value->compression; ?></td>
                              </tr>
                              <tr>
                                <th>Engine Oil Capacity</th>
                                <td><?php echo $value->oil_capacity; ?></td>
                              </tr>
                              <tr>
                                <th>Transmission</th>
                                <td><?php echo $value->transmission; ?></td>
                              </tr>
                              <tr>
                                <th>Oil Replacement</th>
                                <td><?php echo $value->oil_replace; ?></td>
                              </tr>
                              <tr>
                                <th>Gearshift Pattern</th>
                                <td><?php echo $value->gearshift; ?></td>
                              </tr>
                              <tr>
                                <th>(Primary Reduction/Final Reduction)</th>
                                <td><?php echo $value->reduction; ?></td>
                              </tr>
                              <tr>
                                <th>Gear Ratio : 1st</th>
                                <td><?php echo $value->ratio; ?></td>
                              </tr>
                              <tr>
                                <th>Gear radio : 2nd</th>
                                <td><?php echo $value->ratio1; ?></td>
                              </tr>
                              <tr>
                                <th>Gear radio : 3rd</th>
                                <td><?php echo $value->ratio2; ?></td>
                              </tr>
                              <tr>
                                <th>Gear radio : 4th</th>
                                <td><?php echo $value->ratio3; ?></td>
                              </tr>
                              
                            </table>
                        </div>
                      </div>
                
                    </div>
                    <!-- Accordion card -->
                
                    <!-- Accordion card -->
                    <div class="card fadeinTextup">
                
                      <!-- Card header -->
                      <div class="card-header" role="tab" id="headingThree3">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseThree3"
                           aria-expanded="false" aria-controls="collapseThree3">
                          <h5 class="mb-0">
                            DIMENSIONS <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseThree3" class="collapse" role="tabpanel" aria-labelledby="headingThree3"
                           data-parent="#accordionEx">
                        <div class="card-body">
                          
                          <table style="width:100%" class="table-speci">
                              <tr>
                                <th>[W X L X H]</th>
                                <td><?php echo $value->wlh; ?></td>
                              </tr>
                              <tr>
                                <th>Wheelbase</th>
                                <td><?php echo $value->wheelbase; ?></td>
                              </tr>
                              <tr>
                                <th>Weight</th>
                                <td><?php echo $value->weight; ?></td>
                              </tr>
                              <tr>
                                <th>Ground Clearance</th>
                                <td><?php echo $value->ground; ?></td>
                              </tr>
                              <tr>
                                <th>Seat High</th>
                                <td><?php echo $value->seat; ?></td>
                              </tr>
                              <tr>
                                <th>Fuel Tank</th>
                                <td><?php echo $value->fuel_tank; ?></td>
                              </tr>
                              <tr>
                                <th>Caster Angle/Trail</th>
                                <td><?php echo $value->caster; ?></td>
                              </tr>
                              <tr>
                                <th>Frame Type</th>
                                <td><?php echo $value->frame; ?></td>
                              </tr>
                              <tr>
                                <th>Battery</th>
                                <td><?php echo $value->battery; ?></td>
                              </tr>
                              
                            </table>
                        </div>
                      </div>
                
                    </div>
                    <!-- Accordion card -->
                      <div class="card-header fadeinTextup" role="tab" id="headingFour4">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseFour4"
                           aria-expanded="false" aria-controls="collapseFour4">
                          <h5 class="mb-0">
                            SUSPENSION & TIRE <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseFour4" class="collapse" role="tabpanel" aria-labelledby="headingFour4" data-parent="#accordionEx">
                        <div class="card-body">
                          
                          <table style="width:100%" class="table-speci">
                              <tr>
                                <th>Tire Size Front</th>
                                <td><?php echo $value->tire_front; ?></td>
                              </tr>
                              <tr>
                                <th>Tire Size Rear</th>
                                <td><?php echo $value->tire_rear; ?></td>
                              </tr>
                              <tr>
                                <th>Front Brake</th>
                                <td><?php echo $value->front_brake; ?></td>
                              </tr>
                              <tr>
                                <th>Rear Brake</th>
                                <td><?php echo $value->rear_brake; ?></td>
                              </tr>
                              <tr>
                                <th>Tire Type</th>
                                <td><?php echo $value->tire_type; ?></td>
                              </tr>
                              <tr>
                                <th>Suspension Front</th>
                                <td><?php echo $value->suspension; ?></td>
                              </tr>
                              <tr>
                                <th>Suspension Rear</th>
                                <td><?php echo $value->suspension_rear; ?></td>
                              </tr>
                            </table>
                           
                        </div>
                      </div>
                
                    </div>
                
                
                  </div>
                  <!-- Accordion wrapper -->
                
                </div>
        </div>
        
        <?php } else {?>  
        
    <div class="row model-spec specification fadeinTextup sectionscroll">
        <div class="container" >
            <h1 class="head-titel-page"><?=pageTitle();?> ព័ត៌មានបច្ចេកទេស</h1>
        </div>

        <div class="col-md-12">
            <div class="container my-4">

                <h5 class="model-no">
                            <B> ម៉ូឌែលកូដ: </B> <?php echo $value->code; ?>
                          </h5>
                  <!--Accordion wrapper-->
                  <br>
                  <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
              
                    <!-- Accordion card -->
                
                    <!-- Accordion card -->
                    <div class="card fadeinTextup">
                
                      <!-- Card header -->
                      <div class="card-header" role="tab" id="headingTwo2">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                          <h5 class="mb-0">
                            ម៉ាស៊ីន <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseTwo2" class="collapse" role="tabpanel" aria-labelledby="headingTwo2" data-parent="#accordionEx">
                        <div class="card-body">
                            <table style="width:100%" class="table-speci">
                              <tr>
                                <th>ប្រភេទម៉ាស៊ីន  </th>
                                <td><?php echo $value->engine; ?></td>
                              </tr>
                              <tr>
                                <th> អង្កត់ផ្ចិត និងចំងាយចរពិស្តុង  </th>
                                <td><?php echo $value->bore; ?></td>
                              </tr>
                              <tr>
                                <th>  ទំហំមាឌស៊ីឡាំង  </th>
                                <td><?php echo $value->displacement; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធប្រេង  </th>
                                <td><?php echo $value->fuel; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រភេទប្រេងឥន្ធនៈ  </th>
                                <td><?php echo $value->feul_type; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធចំហេះ  </th>
                                <td><?php echo $value->ignition; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ទបញ្ចូលចលនាចុងក្រោយ  </th>
                                <td><?php echo $value->final_drive; ?></td>
                              </tr>
                              <tr>
                                <th> ប្រព័ន្ធលេខ  </th>
                                <td><?php echo $value->clutch; ?></td>
                              </tr>
                              <tr>
                                <th> ប្រព័ន្ធបញ្ឆេះម៉ាសុីន  </th>
                                <td><?php echo $value->starter; ?></td>
                              </tr>
                              <tr>
                                <th> កម្រិតបង្ហាប់ </th>
                                <td><?php echo $value->compression; ?></td>
                              </tr>
                              <tr>
                                <th> ចំណុះប្រេងម៉ាស៊ីន </th>
                                <td><?php echo $value->oil_capacity; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធលេខ  </th>
                                <td><?php echo $value->transmission; ?></td>
                              </tr>
                              <tr>
                                <th>  រយៈពេលដែលត្រូវប្តូរប្រេងម៉ាស៊ីន  </th>
                                <td><?php echo $value->oil_replace; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធបញ្ចូលចលនា (ចង្កឹះលេខ)  </th>
                                <td><?php echo $value->gearshift; ?></td>
                              </tr>
                              <tr>
                                <th>  ផលធៀបពីញ៉ុងងឺ/ផលធៀបច្រវាក់ពីញ៉ុង </th>
                                <td><?php echo $value->reduction; ?></td>
                              </tr>
                              <tr>
                                <th>  ផលធៀបពីញ៉ុងលេខ : លេខ 1  </th>
                                <td><?php echo $value->ratio; ?></td>
                              </tr>
                              <tr>
                                <th>  ផលធៀបពីញ៉ុងលេខ : លេខ 2  </th>
                                <td><?php echo $value->ratio1; ?></td>
                              </tr>
                              <tr>
                                <th>  ផលធៀបពីញ៉ុងលេខ : លេខ 3  </th>
                                <td><?php echo $value->ratio2; ?></td>
                              </tr>
                              <tr>
                                <th>  ផលធៀបពីញ៉ុងលេខ : លេខ 4  </th>
                                <td><?php echo $value->ratio3; ?></td>
                              </tr>
                              
                            </table>
                        </div>
                      </div>
                
                    </div>
                    <!-- Accordion card -->
                
                    <!-- Accordion card -->
                    <div class="card fadeinTextup">
                
                      <!-- Card header -->
                      <div class="card-header" role="tab" id="headingThree3">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseThree3"
                           aria-expanded="false" aria-controls="collapseThree3">
                          <h5 class="mb-0">
                            វិមាត្រ <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseThree3" class="collapse" role="tabpanel" aria-labelledby="headingThree3"
                           data-parent="#accordionEx">
                        <div class="card-body">
                          
                          <table style="width:100%" class="table-speci">
                              <tr>
                                <th> បណ្តោយ x ទទឹង x កំពស់  </th>
                                <td><?php echo $value->wlh; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រវែងពីកង់មុខទៅកង់ក្រោយ  </th>
                                <td><?php echo $value->wheelbase; ?></td>
                              </tr>
                              <tr>
                                <th> ទម្ងន់   </th>
                                <td><?php echo $value->weight; ?></td>
                              </tr>
                              <tr>
                                <th>  គំលាតពីដី   </th>
                                <td><?php echo $value->ground; ?></td>
                              </tr>
                              <tr>
                                <th>  កម្ពស់កែប  </th>
                                <td><?php echo $value->seat; ?></td>
                              </tr>
                              <tr>
                                <th>  ចំណុះធុងសាំង  </th>
                                <td><?php echo $value->fuel_tank; ?></td>
                              </tr>
                              <tr>
                                <th>  មុំទម្រេតជំពាស់មុខ   </th>
                                <td><?php echo $value->caster; ?></td>
                              </tr>
                              <tr>
                                <th>  តួម៉ូតូ  </th>
                                <td><?php echo $value->frame; ?></td>
                              </tr>
                              <tr>
                                <th>  អាគុយ  </th>
                                <td><?php echo $value->battery; ?></td>
                              </tr>
                              
                            </table>
                        </div>
                      </div>
                
                    </div>
                    <!-- Accordion card -->
                      <div class="card-header fadeinTextup" role="tab" id="headingFour4">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseFour4"
                           aria-expanded="false" aria-controls="collapseFour4">
                          <h5 class="mb-0">
                            ប្រព័ន្ធបូម និងសំបកកង់ <i class="fas fa-angle-down rotate-icon"></i>
                          </h5>
                        </a>
                      </div>
                
                      <!-- Card body -->
                      <div id="collapseFour4" class="collapse" role="tabpanel" aria-labelledby="headingFour4" data-parent="#accordionEx">
                        <div class="card-body">
                          
                          <table style="width:100%" class="table-speci">
                              <tr>
                                <th> ទំហំសំបកកង់ (មុខ)   </th>
                                <td><?php echo $value->tire_front; ?></td>
                              </tr>
                              <tr>
                                <th>  ទំហំសំបកកង់ (ក្រោយ)  </th>
                                <td><?php echo $value->tire_rear; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធហ្វ្រាំង (មុខ)  </th>
                                <td><?php echo $value->front_brake; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធហ្រ្វាំង (ក្រោយ)   </th>
                                <td><?php echo $value->rear_brake; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធកង់  </th>
                                <td><?php echo $value->tire_type; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធបូមមុខ   </th>
                                <td><?php echo $value->suspension; ?></td>
                              </tr>
                              <tr>
                                <th>  ប្រព័ន្ធបូមក្រោយ  </th>
                                <td><?php echo $value->suspension_rear; ?></td>
                              </tr>
                            </table>
                           
                        </div>
                      </div>
                
                    </div>
                
                
                  </div>
                  <!-- Accordion wrapper -->
                
                </div>
        </div>    
        
        <?php } ?> 
        
    </div>
    <br>
    <?php } ?>  
    
<?php }?>

<script>
        $('.product-nav-bar li').click( function(){
            if ( $(this).hasClass('active') ) {
                $(this).removeClass('active');
            } else {
                $('.product-nav-bar li.active').removeClass('active');
                $(this).addClass('active');    
            }
        });
        
        
        $('.overview').append(
            $('.overview').attr('id', 'overview')
        );
        $('.main-feature1').append(
            $('.main-feature1').attr('id', 'main-feature1')
        );
        $('.view-full-degree').append(
            $('.view-full-degree').attr('id', 'view-full-degree')
        );
        $('.other-feature').append(
            $('.other-feature').attr('id', 'other-feature')
        );
        $('.smart-feature').append(
            $('.smart-feature').attr('id', 'smart-feature')
        );
        $('.specification').append(
            $('.specification').attr('id', 'specification')
        );
    
    
    $('.product-nav-bar li a').click(function (e) {
        $('html, body').animate({
            scrollTop: $($(this).attr('href')).offset().top - 50
        }, 500); 
    });
        
       
        
        // 360 View
            var img_360 = $('.content-img-360').attr("src");
              var threesixty = new ThreeSixty(document.getElementById('threesixty'), {
              image: img_360,
              width: 840,
              height: 840,
              count: 36,
              perRow: 4,
              speed: 100,
              // prev: document.getElementById('prev'),
              // next: document.getElementById('next') 
            });
        
            threesixty.stop();
            
            $('.image-360').on('click', function(){
                threesixty.play();
            });

</script>

<?php require(base_path().'/themes/giant/footer.php'); ?>