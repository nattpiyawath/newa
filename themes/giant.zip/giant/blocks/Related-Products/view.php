<div class="get-relate-product">
    <?php
        echo getRelated();
    ?>
</div>
<br><br>