@extends('template')
@section('title', 'Edit - '.$specification->title)
@section('content')
<style type="text/css">
   textarea.form-control {height: 80px;}
   .card-view {max-width: 1280px;margin: 0 auto;}
   .ck-editor__editable {min-height: 200px;}
   .checkbox input[type="checkbox"]{opacity: 1;position: unset;margin-left: 0;}
</style>
@php
$myStorage = '/storage/app/uploads/';
@endphp

<div class="row">
   <div class="col-md-12">
      <div class="panel panel-default card-view">
         <div class="panel-heading">
            <div class="pull-left">
               <h6 class="panel-title txt-dark">Edit Specification</h6>
            </div>
            <div class="clearfix"></div>
         </div>
         <div class="panel-wrapper collapse in">
            <div class="panel-body">
               <div class="row">
                  <div class="col-sm-12 col-xs-12">
                     <div class="form-wrap">
                     {!! Form::open(['route' => ['specification.update', $specification->id], 'method' => 'PATCh']) !!}
                        <input type="hidden" name="lang_code" value="{{$lang}}">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label for="page-status">Status</label>
                                    <select class="form-control" data-placeholder="Status" name="is_published">
                                       @php 
                                       $status = $specification->is_published;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Publish</option>
                                       <option value="0">Draft</option>
                                       @else
                                       <option value="0" selected>Draft</option>
                                       <option value="1">Publish</option>
                                       @endif
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label for="select-country">Translate Of </label>
                                    <select class="form-control selectpicker" id="select-page" data-live-search="true" name="translate_id">
                                       
                                        <option value="0">Select...</option>
                                        
                                    </select>

                                    <script type="text/javascript">
                                            $(function() {
                                                $('.selectpicker').selectpicker();
                                            });

                                    </script>
                                 </div>
                              </div>

                              <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Select Page</label>
                                    <select class="form-control" data-placeholder="Spare Part's Category" name="page_id">
                                        
                                    <option value="0">Select...</option>

                                    </select>

                                </div>
                              </div>

                              <div class="col-md-3">
                                 <div class="form-group">
                                    <div class="form-actions mt-10" style="text-align: right;">
                                       <a class="btn btn-default btn-close" href="{{url('admin/specification?lang='.$lang)}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back</a>
                                       {{ Form::button('<i class="fa fa-floppy-o" aria-hidden="true"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success mr-10'] )  }}
                                    </div>
                                 </div>
                              </div>
                              <!--/span-->
                           </div>
                        </div>
                        <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Model Code</h6>
                        <hr class="light-grey-hr">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="form-group @if($errors->has('code')) has-error @endif">
                                 <label class="control-label mb-10">Model Code</label>
                                    {!! Form::text('code', $specification->code, ['class' => 'form-control', 'placeholder' => 'Model Code']) !!}
                                    @if ($errors->has('code'))
                                    <span class="help-block">{!! $errors->first('code') !!}</span>
                                    @endif
                              </div>
                           </div>
                        </div>
                     </div>

                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Engine</h6>
                     <hr class="light-grey-hr">
                     <div class="row">
                            <div class="col-md-3">
                              <div class="form-group @if($errors->has('engine')) has-error @endif">
                                 <label class="control-label mb-10">Engine System</label>
                                    {!! Form::text('engine', $specification->engine, ['class' => 'form-control', 'placeholder' => 'Engine System']) !!}
                                    @if ($errors->has('engine'))
                                    <span class="help-block">{!! $errors->first('engine') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('bore')) has-error @endif">
                                 <label class="control-label mb-10">Bore and Stroke</label>
                                    {!! Form::text('bore', $specification->bore, ['class' => 'form-control', 'placeholder' => 'Bore and Stroke']) !!}
                                    @if ($errors->has('bore'))
                                    <span class="help-block">{!! $errors->first('bore') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('displacement')) has-error @endif">
                                 <label class="control-label mb-10">Displacement</label>
                                    {!! Form::text('displacement', $specification->displacement, ['class' => 'form-control', 'placeholder' => 'Displacement']) !!}
                                    @if ($errors->has('displacement'))
                                    <span class="help-block">{!! $errors->first('displacement') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('fuel')) has-error @endif">
                                 <label class="control-label mb-10">Fuel System</label>
                                    {!! Form::text('fuel', $specification->fuel, ['class' => 'form-control', 'placeholder' => 'Fuel System']) !!}
                                    @if ($errors->has('fuel'))
                                    <span class="help-block">{!! $errors->first('fuel') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('fuel_type')) has-error @endif">
                                 <label class="control-label mb-10">Fuel Type</label>
                                    {!! Form::text('fuel_type', $specification->fuel_type, ['class' => 'form-control', 'placeholder' => 'Fuel Type']) !!}
                                    @if ($errors->has('fuel_type'))
                                    <span class="help-block">{!! $errors->first('fuel_type') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('ignition')) has-error @endif">
                                 <label class="control-label mb-10">Ignition System</label>
                                    {!! Form::text('ignition', $specification->ignition, ['class' => 'form-control', 'placeholder' => 'Ignition System']) !!}
                                    @if ($errors->has('ignition'))
                                    <span class="help-block">{!! $errors->first('ignition') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('final_drive')) has-error @endif">
                                 <label class="control-label mb-10">Final Drive Type</label>
                                    {!! Form::text('final_drive', $specification->final_drive, ['class' => 'form-control', 'placeholder' => 'Final Drive Type']) !!}
                                    @if ($errors->has('final_drive'))
                                    <span class="help-block">{!! $errors->first('final_drive') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('clutch')) has-error @endif">
                                 <label class="control-label mb-10">Clutch System</label>
                                    {!! Form::text('clutch', $specification->clutch, ['class' => 'form-control', 'placeholder' => 'Clutch System']) !!}
                                    @if ($errors->has('clutch'))
                                    <span class="help-block">{!! $errors->first('clutch') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('starter')) has-error @endif">
                                 <label class="control-label mb-10">Starter System</label>
                                    {!! Form::text('starter', $specification->starter, ['class' => 'form-control', 'placeholder' => 'Starter System']) !!}
                                    @if ($errors->has('starter'))
                                    <span class="help-block">{!! $errors->first('starter') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('compression')) has-error @endif">
                                 <label class="control-label mb-10">Compression Ratio</label>
                                    {!! Form::text('compression', $specification->compression, ['class' => 'form-control', 'placeholder' => 'Compression Ratio']) !!}
                                    @if ($errors->has('compression'))
                                    <span class="help-block">{!! $errors->first('compression') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('oil_capacity')) has-error @endif">
                                 <label class="control-label mb-10">Engine oil capacity</label>
                                    {!! Form::text('oil_capacity', $specification->oil_capacity, ['class' => 'form-control', 'placeholder' => 'Engine oil capacity']) !!}
                                    @if ($errors->has('oil_capacity'))
                                    <span class="help-block">{!! $errors->first('oil_capacity') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('transmission')) has-error @endif">
                                 <label class="control-label mb-10">Transmission</label>
                                    {!! Form::text('transmission', $specification->transmission, ['class' => 'form-control', 'placeholder' => 'Transmission']) !!}
                                    @if ($errors->has('transmission'))
                                    <span class="help-block">{!! $errors->first('transmission') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('oil_replace')) has-error @endif">
                                 <label class="control-label mb-10">Oil replacement</label>
                                    {!! Form::text('oil_replace', $specification->oil_replace, ['class' => 'form-control', 'placeholder' => 'Oil replacement']) !!}
                                    @if ($errors->has('oil_replace'))
                                    <span class="help-block">{!! $errors->first('oil_replace') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('gearshift')) has-error @endif">
                                 <label class="control-label mb-10">Gearshift pattern</label>
                                    {!! Form::text('gearshift', $specification->gearshift, ['class' => 'form-control', 'placeholder' => 'Gearshift pattern']) !!}
                                    @if ($errors->has('gearshift'))
                                    <span class="help-block">{!! $errors->first('gearshift') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('reduction')) has-error @endif">
                                 <label class="control-label mb-10">(Primary reduction/Final reduction)</label>
                                    {!! Form::text('reduction', $specification->reduction, ['class' => 'form-control', 'placeholder' => 'Primary reduction/Final reduction']) !!}
                                    @if ($errors->has('reduction'))
                                    <span class="help-block">{!! $errors->first('reduction') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('ratio')) has-error @endif">
                                 <label class="control-label mb-10">Gear ratio : 1st</label>
                                    {!! Form::text('ratio', $specification->ratio, ['class' => 'form-control', 'placeholder' => 'Gear ratio : 1st']) !!}
                                    @if ($errors->has('ratio'))
                                    <span class="help-block">{!! $errors->first('ratio') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio1')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 2nd</label>
                                    {!! Form::text('radio1', $specification->radio1, ['class' => 'form-control', 'placeholder' => 'Gear radio : 2nd']) !!}
                                    @if ($errors->has('radio1'))
                                    <span class="help-block">{!! $errors->first('radio1') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio2')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 3rd</label>
                                    {!! Form::text('radio2', $specification->radio2, ['class' => 'form-control', 'placeholder' => 'Gear radio : 3rd']) !!}
                                    @if ($errors->has('radio2'))
                                    <span class="help-block">{!! $errors->first('radio2') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio3')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 4th</label>
                                    {!! Form::text('radio3', $specification->radio3, ['class' => 'form-control', 'placeholder' => 'Gear radio : 4th']) !!}
                                    @if ($errors->has('radio3'))
                                    <span class="help-block">{!! $errors->first('radio3') !!}</span>
                                    @endif
                              </div>
                           </div>
                     </div>

                     <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Dimensions</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('wlh')) has-error @endif">
                                 <label class="control-label mb-10">[W x L x H]</label>
                                    {!! Form::text('wlh', $specification->wlh, ['class' => 'form-control', 'placeholder' => '[W x L x H]']) !!}
                                    @if ($errors->has('wlh'))
                                    <span class="help-block">{!! $errors->first('wlh') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('wheelbase')) has-error @endif">
                                 <label class="control-label mb-10">Wheelbase</label>
                                    {!! Form::text('wheelbase', $specification->wheelbase, ['class' => 'form-control', 'placeholder' => 'Wheelbase']) !!}
                                    @if ($errors->has('wheelbase'))
                                    <span class="help-block">{!! $errors->first('wheelbase') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('weight')) has-error @endif">
                                 <label class="control-label mb-10">Weight</label>
                                    {!! Form::text('weight', $specification->weight, ['class' => 'form-control', 'placeholder' => 'Weight']) !!}
                                    @if ($errors->has('weight'))
                                    <span class="help-block">{!! $errors->first('weight') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('ground')) has-error @endif">
                                 <label class="control-label mb-10">Ground Clearance</label>
                                    {!! Form::text('ground', $specification->ground, ['class' => 'form-control', 'placeholder' => 'Ground Clearance']) !!}
                                    @if ($errors->has('ground'))
                                    <span class="help-block">{!! $errors->first('ground') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('seat')) has-error @endif">
                                 <label class="control-label mb-10">Seat High</label>
                                    {!! Form::text('seat', $specification->seat, ['class' => 'form-control', 'placeholder' => 'Seat High']) !!}
                                    @if ($errors->has('seat'))
                                    <span class="help-block">{!! $errors->first('seat') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('fuel_tank')) has-error @endif">
                                 <label class="control-label mb-10">Fuel Tank</label>
                                    {!! Form::text('fuel_tank', $specification->fuel_tank, ['class' => 'form-control', 'placeholder' => 'Fuel Tank']) !!}
                                    @if ($errors->has('fuel_tank'))
                                    <span class="help-block">{!! $errors->first('fuel_tank') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('caster')) has-error @endif">
                                 <label class="control-label mb-10">Caster Angle/Trail</label>
                                    {!! Form::text('caster', $specification->caster, ['class' => 'form-control', 'placeholder' => 'Caster Angle/Trail']) !!}
                                    @if ($errors->has('caster'))
                                    <span class="help-block">{!! $errors->first('caster') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('frame')) has-error @endif">
                                 <label class="control-label mb-10">Frame Type</label>
                                    {!! Form::text('frame', $specification->frame, ['class' => 'form-control', 'placeholder' => 'Frame Type']) !!}
                                    @if ($errors->has('frame'))
                                    <span class="help-block">{!! $errors->first('frame') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('battery')) has-error @endif">
                                 <label class="control-label mb-10">Battery</label>
                                    {!! Form::text('battery', $specification->battery, ['class' => 'form-control', 'placeholder' => 'Battery']) !!}
                                    @if ($errors->has('battery'))
                                    <span class="help-block">{!! $errors->first('battery') !!}</span>
                                    @endif
                              </div>
                           </div>

                     </div>

                     <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Suspension & Tire</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                            <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_front')) has-error @endif">
                                 <label class="control-label mb-10">Tire Size Front</label>
                                    {!! Form::text('tire_front', $specification->tire_front, ['class' => 'form-control', 'placeholder' => 'Tire Size Front']) !!}
                                    @if ($errors->has('tire_front'))
                                    <span class="help-block">{!! $errors->first('tire_front') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_rear')) has-error @endif">
                                 <label class="control-label mb-10">Tire Size Rear</label>
                                    {!! Form::text('tire_rear', $specification->tire_rear, ['class' => 'form-control', 'placeholder' => 'Tire Size Rear']) !!}
                                    @if ($errors->has('tire_rear'))
                                    <span class="help-block">{!! $errors->first('tire_rear') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('front_brake')) has-error @endif">
                                 <label class="control-label mb-10">Front brake</label>
                                    {!! Form::text('front_brake', $specification->front_brake, ['class' => 'form-control', 'placeholder' => 'Front brake']) !!}
                                    @if ($errors->has('front_brake'))
                                    <span class="help-block">{!! $errors->first('front_brake') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('rear_brake')) has-error @endif">
                                 <label class="control-label mb-10">Rear brake</label>
                                    {!! Form::text('rear_brake', $specification->rear_brake, ['class' => 'form-control', 'placeholder' => 'Rear brake']) !!}
                                    @if ($errors->has('rear_brake'))
                                    <span class="help-block">{!! $errors->first('rear_brake') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_type')) has-error @endif">
                                 <label class="control-label mb-10">Tire Type</label>
                                    {!! Form::text('tire_type', $specification->tire_type, ['class' => 'form-control', 'placeholder' => 'Tire Type']) !!}
                                    @if ($errors->has('tire_type'))
                                    <span class="help-block">{!! $errors->first('tire_type') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('suspension')) has-error @endif">
                                 <label class="control-label mb-10">Suspension Front</label>
                                    {!! Form::text('suspension', $specification->suspension, ['class' => 'form-control', 'placeholder' => 'Suspension Front']) !!}
                                    @if ($errors->has('suspension'))
                                    <span class="help-block">{!! $errors->first('suspension') !!}</span>
                                    @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('suspension_rear')) has-error @endif">
                                 <label class="control-label mb-10">Suspension Rear</label>
                                    {!! Form::text('suspension_rear', $specification->suspension_rear, ['class' => 'form-control', 'placeholder' => 'Suspension Rear']) !!}
                                    @if ($errors->has('suspension_rear'))
                                    <span class="help-block">{!! $errors->first('suspension_rear') !!}</span>
                                    @endif
                              </div>
                           </div>

                     <input type="hidden" name="lang_code" value="{{$lang}}">

                  </div>

                  <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Spare Part</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                            <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">Honda Smart Technology</label>
                                    <select class="form-control" data-placeholder="Honda Smart Technology" name="hst">
                                    @php 
                                       $status = $specification->hst;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">PGM-FI</label>
                                    <select class="form-control" data-placeholder="PGM-FI" name="pgm">
                                    @php 
                                       $status = $specification->pgm;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">ESP</label>
                                    <select class="form-control" data-placeholder="ESP" name="esp">
                                    @php 
                                       $status = $specification->esp;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">ESP Plus</label>
                                    <select class="form-control" data-placeholder="ESP Plus" name="esp_plus">
                                    @php 
                                       $status = $specification->esp_plus;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">A Idling</label>
                                    <select class="form-control" data-placeholder="A Idling" name="idling">
                                    @php 
                                       $status = $specification->idling;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">Combi Brake</label>
                                    <select class="form-control" data-placeholder="Combi Brake" name="combi">
                                    @php 
                                       $status = $specification->combi;
                                       @endphp
                                       @if ($status == 1)
                                       <option value="1" selected>Yes</option>
                                       <option value="0">No</option>
                                       @else
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                       @endif
                                    </select>
                              </div>
                           </div>
                  </div>
               

               </div>
               {!! Form::close() !!}
            </div>
         </div>
      </div>
   </div>
</div>
</div>      
</div>
</div>
@endsection