<?php require(base_path().'/themes/giant/header.php'); ?>

<?= $body ?>

<?php require(base_path().'/themes/giant/footer.php'); ?>


<style>
    .main-nav nav .navbar-nav .nav-item a{padding-top:5px !important;}
    .navbar-expand-md .navbar-nav .nav-link {padding: 5px 10px;}
</style>