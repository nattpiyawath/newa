@extends('template')

@section('title', 'Create A Gallery')

@section('content')


<style type="text/css">
    textarea.form-control {height: 80px;}
    .card-view {max-width: 1280px;margin: 0 auto;}
    button#addMore {
      position: absolute;
      right: 0;
      margin-top: -24px;
  }
  .close-x{display: flex;}
  img#cover-image {
    max-width: 340px;
}
</style>


<div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default card-view">
                                <div class="panel-heading">
                                    <div class="pull-left">
                                        <h6 class="panel-title txt-dark">Create A Gallery</h6>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="panel-wrapper collapse in">
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="form-wrap">


                                                    <form action="{{ route('gallery.store') }}" method="post">
                                                      @csrf



                                                        <input type="hidden" name="lang_code" value="{{$lang}}">
                                                        
                                                        <div class="form-body">

                                                            <div class="row">
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <label for="page-status">Status</label>
                                                                        <select class="form-control" data-placeholder="Status" name="is_published">
                                                                                <option value="0" selected>Draft</option>
                                                                                <option value="1">Publish</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3"> 
                                                                    <div class="form-group">
                                                                    <label for="select-country">Translate Of </label>

                                                            <select class="form-control selectpicker" id="select-page" data-live-search="true" name="translate_id">

                                                                    <option value="0">Select...</option>
                                                                            @foreach($gallery as $pg)
                                                                                <option data-tokens="{{$pg->title}}" value="{{$pg->slug}}">{{$pg->gallery_name}}</option>
                                                                            @endforeach
                                                                    </select>

                                                                    
                                                                    </div>
                                                                </div>

                                                                
                                                                <!--/span-->
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <div class="form-actions mt-10" style="text-align: right;">
                                                                        <a class="btn btn-default btn-close" href="{{url('admin/gallery?lang='.$lang)}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back</a>
                                                                        {{ Form::button('<i class="fa fa-floppy-o" aria-hidden="true"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success mr-10'] )  }}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!--/span-->
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group @if($errors->has('gallery_name')) has-error @endif">
                                                                        <label class="control-label mb-10">GAllery Name</label>

                                                                        <input type="text" class="form-control" name="gallery_name" value="{{ old('gallery_name') }}" placeholder="Enter Name" />

                                                                        @if ($errors->has('gallery_name'))
                                                                            <span class="help-block">{!! $errors->first('gallery_name') !!}</span>
                                                                        @endif
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label class="control-label mb-10">Add Gallery For</label>
                                                                        <select class="form-control selectpicker" data-live-search="true" data-placeholder="Choose a Parent" name="page_id">
                                                                            <option value="0">Select...</option>
                                                                            @foreach($page as $pages)
                                                                                <option value="{{$pages->id}}">{{$pages->title}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div id="addRow">

                                                              <div class="row">
                                                                  <div class="col-md-3">
                                                                      <div class="form-group">

                                                                        <a class="button secondary postfix image_selector" data-upateimage="feature_image"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                                                        <img class="cover-image" id="cover-image" height="150" src="{{ URL('assets/pagebuilder/images') }}/cover-1920x400.jpg"/>
                                                                        <input type="hidden" id="feature_image" name="image_url[]" value="{{ URL('assets/pagebuilder/images') }}/cover-1920x400.jpg" />
                                                                       
                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-3">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_title[]" value="{{ old('image_title') }}" placeholder="Enter Title" />
                                                                      </div>
                                                                  </div>

                                                                  <div class="col-md-4">
                                                                      <div class="form-group">
                                                                          <input type="text" class="form-control" name="image_caption[]" value="{{ old('image_caption') }}" placeholder="Enter Caption" />
                                                                      </div>
                                                                  </div>
                                                                  <div class="col-md-2">
                                                                      <div class="form-group">
                                                                        
                                                                      </div>
                                                                  </div>
                                                                </div>
                                                            </div>

                                                                
                                                            </div>

                                                          </form>

                                                          <button id="addMore" class="btn btn-success btn-sm"><i class="fa fa-plus" aria-hidden="true"></i> </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>      
                        </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.6/handlebars.min.js"></script> 

<script id="document-template" type="text/x-handlebars-template">
<div class="row delete_add_more_item" id="delete_add_more_item">
  <div class="col-md-3">
    <div class="form-group">
      <a class="button secondary postfix image_selector" data-upateimage="feature_image"><i class="fa fa-pencil" aria-hidden="true"></i></a>
      <img class="cover-image" id="cover-image" height="150" src="{{ URL('assets/pagebuilder/images') }}/cover-1920x400.jpg"/>
      <input type="hidden" id="feature_image" name="image_url[]" value="{{ URL('assets/pagebuilder/images') }}/cover-1920x400.jpg" />
    </div>
  </div>

  <div class="col-md-3">
    <div class="form-group">
        <input type="text" class="form-control" name="image_title[]" placeholder="Enter Title" value="@{{ image_title }}">
    </div>
  </div>

  <div class="col-md-4">
    <div class="form-group">
        <input type="text" class="form-control" name="image_caption[]" placeholder="Enter Caption" value="@{{ image_caption }}"> 
    </div>
  </div>

  <div class="col-md-2">
    <div class="form-group close-x">
        <span class="removeaddmore" style="cursor:pointer;color:red;padding: 4px 10px;border-radius: 90%;border: solid 1px;"><i class="fa fa-times" aria-hidden="true"></i><span>
    </div>
  </div>
</div>
 </script>

 <script type="text/javascript">

  $(function() {
    $('.selectpicker').selectpicker();
  });

</script>


<script type="text/javascript">
 
 $(document).on('click','#addMore',function(){

     var image_url = $("#image_url").val();
     var image_title = $("#image_title").val();
     var image_caption = $("#image_caption").val();
     var source = $("#document-template").html();
     var template = Handlebars.compile(source);

     var data = {
        image_url: image_url,
        image_title: image_title,
        image_caption: image_caption
     }

     var html = template(data);
     $("#addRow").append(html)
 });

  $(document).on('click','.removeaddmore',function(event){
    $(this).closest('.delete_add_more_item').remove();
  });
                    
</script>


<div class="modal fade in"><div id="elfinder"></div></div>


<script type="text/javascript">
  $(document).on('click','.image_selector',function(event){
    event.preventDefault();

    $this = $(this);

    $('.modal').show();

    updateID = $this.attr('data-upateimage');

    // fire elfinder for image selection
    $('#elfinder').elfinder({
    url : '{{ route("elfinder.connector") }}',

    commandsOptions: {
      getfile: {
      oncomplete: 'destroy' 
      }
    },
    dialog: {width: 900, modal: true, title: 'Select a file'},
    resizable: false,
    commandsOptions: {
      getfile: {
      oncomplete: 'destroy',
      folders  : false
      }
    },
    getFileCallback: function(url) {
      //console.log(url)
      document.getElementById(updateID).value = url.url;
      $this.next().attr('src', url.url);
      $('.modal').hide();
    }
    }).elfinder('instance');

  });
</script>


@endsection