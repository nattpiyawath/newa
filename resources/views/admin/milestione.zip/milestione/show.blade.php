@extends('template')

@section('content')
    <h3>{{$posts->pro_title}}</h3>
    <p>{{$posts->pro_remark}}</p>
@endsection