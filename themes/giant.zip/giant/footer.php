<!-- Footer -->

<?php 
$currentLocale = app()->getLocale();

if (isset($_GET['page'])){
   echo '<h1>Deposit Calculator</h1>';
} 

else{ 
    $lang_code = app()->getLocale();
    $policy = 'I have read and agree to the privacy policy';
    $call_us = 'CALL US';
    $subscribe = 'Subscribe';
    $enter_email = 'Your email address';
    $copyright = '© Copyright N. C. X. CO., LTD. 2021';
    $reserved = 'All Right Reserved.';
    
  
    if ($lang_code == 'kh'){
        $policy = 'ខ្ញុំបានអាននិងយល់ព្រមលើគោលការណ៍ភាពឯកជន';
        $call_us = 'ទំនាក់ទំនង';
        $subscribe = 'ជាវ';
        $enter_email = 'អាស័យ​ដ្ឋាន​អ៊ី​ម៉េ​ល';
        $copyright = 'រក្សាសិទ្ធដោយក្រុមហ៊ុន អិន ស៊ី អិច ខូអិលធីឌី ២០២១';
        $reserved = 'រក្សា​សិទ្ធ​គ្រប់យ៉ាង';
  
    } else{echo '';}

?>



<footer class="footer-area two three pt-100">
    <div class="container footer-top">
            <div class="row goup-footer-logo">
                <div class="col-sm-6 logo-honda-footer">
                    <img src="<?=url('storage/app/uploads/')?>/logo/logo-footer.jpg" alt="Logo">
                    
                </div>
                <div class="col-sm-6 call-center">
                    <div class="text-contact-footer">
                       <p class="call-us"><?php echo $call_us ;?></p>
                       <span class="contact-number">010 922 922</span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" viewBox="0 0 69.89 69.891">
  <path id="FontAwsome_headset_" data-name="FontAwsome (headset)" d="M26.209,28.393a4.369,4.369,0,0,0-4.368-4.368H19.657a8.736,8.736,0,0,0-8.736,8.736v6.552a8.736,8.736,0,0,0,8.736,8.736h2.184a4.369,4.369,0,0,0,4.368-4.368ZM50.234,48.049a8.736,8.736,0,0,0,8.736-8.736V32.761a8.736,8.736,0,0,0-8.736-8.736H48.049a4.369,4.369,0,0,0-4.368,4.368V43.681a4.369,4.369,0,0,0,4.368,4.368ZM34.945,0C15.45,0,.625,16.221,0,34.945v2.184a2.183,2.183,0,0,0,2.184,2.184H4.368a2.183,2.183,0,0,0,2.184-2.184V34.945a28.393,28.393,0,1,1,56.786,0h-.016c.011.332.016,22.621.016,22.621a5.771,5.771,0,0,1-5.771,5.771H43.681a6.552,6.552,0,0,0-6.552-6.552H32.761a6.552,6.552,0,1,0,0,13.1H57.567A12.324,12.324,0,0,0,69.89,57.567V34.945C69.265,16.221,54.441,0,34.945,0Z"/>
</svg>

                </div>
            </div>
            
        <div class="row bottom-footer">
            <div class="col-sm-2">
                <div class="footer-item">
                    <div class="footer-link" id="fotter-1">
                        <?php
                            $menu_setting = 'footer_1';
                            $menu_setting = Helper::getSetting($menu_setting);
                            $t_id = Helper::getMenu_ID($menu_setting);
                            $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id);
                            $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                            $menu_title = Helper::getMenuNamebyId($menu_by_lang_and_id);
                        ?>

                        <h3><?=$menu_title?></h3>
                            <ul>
                            <?php foreach($navigation as $itemP):?>
                                <li>
                                    <i class='bx bx-chevron-right' ></i><a href="<?php echo $itemP->link;?>"><?php echo $itemP->label;?></a>
                                </li>

                            <?php endforeach; ?>
                            </ul>
                    </div>
                </div>
            </div>

            <div class="col-sm-2">
                <div class="footer-item">
                    <div class="footer-link">
                        <?php
                            $menu_setting = 'footer_2';
                            $menu_setting = Helper::getSetting($menu_setting);
                            $t_id = Helper::getMenu_ID($menu_setting);
                            $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id);
                            $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                            $menu_title = Helper::getMenuNamebyId($menu_by_lang_and_id);
                        ?>

                        <h3><?=$menu_title?></h3>
                            <ul>
                            <?php foreach($navigation as $itemP):?>
                                <li>
                                    <i class='bx bx-chevron-right' ></i><a href="<?php echo $itemP->link;?>"><?php echo $itemP->label;?></a>
                                </li>

                            <?php endforeach; ?>
                            </ul>
                    </div>
                </div>
            </div>

            <div class="col-sm-2">
                <div class="footer-item">
                    <div class="footer-link">
                        <?php
                            $menu_setting = 'footer_3';
                            $menu_setting = Helper::getSetting($menu_setting);
                            $t_id = Helper::getMenu_ID($menu_setting);
                            $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id);
                            $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                            $menu_title = Helper::getMenuNamebyId($menu_by_lang_and_id);
                        ?>

                        <h3><?=$menu_title?></h3>
                            <ul>
                            <?php foreach($navigation as $itemP):?>
                                <li>
                                    <i class='bx bx-chevron-right' ></i><a href="<?php echo $itemP->link;?>"><?php echo $itemP->label;?></a>
                                </li>

                            <?php endforeach; ?>
                            </ul>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="footer-item">
                    <div class="footer-link">
                        <?php
                            $menu_setting = 'footer_4';
                            $menu_setting = Helper::getSetting($menu_setting);
                            $t_id = Helper::getMenu_ID($menu_setting);
                            $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id);
                            $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                            $menu_title = Helper::getMenuNamebyId($menu_by_lang_and_id);
                        ?>

                        <h3><?=$menu_title?></h3>
                            <ul>
                            <?php foreach($navigation as $itemP):?>
                                <li>
                                    <i class='bx bx-chevron-right' ></i><a href="<?php echo $itemP->link;?>"><?php echo $itemP->label;?></a>
                                </li>

                            <?php endforeach; ?>
                            </ul>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="footer-item">
                    <div class="footer-link">
                        <?php
                            $menu_setting = 'footer_5';
                            $menu_setting = Helper::getSetting($menu_setting);
                            $t_id = Helper::getMenu_ID($menu_setting);
                            $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id);
                            $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                            $menu_title = Helper::getMenuNamebyId($menu_by_lang_and_id);
                        ?>

                        <h3><?=$menu_title?></h3>
                       
                        <form class="form-subscribe" action="#">
                        <div class="input-group">
                          <input type="text" class="form-control input-lg" placeholder="<?php echo $enter_email ;?>">
                          <span class="input-group-btn">
                            <button class="btn btn-success" type="submit" ><?php echo $subscribe ;?></button>
                          </span>
                        </div>
                        <div class="check-dispaly">
                             <input type="checkbox" id="subscribe-2"/>
                             <label for="subscribe-2"><?php echo $policy ;?></label>
                        </div>     
                      </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div>
        <div class="container footer-copyright-top">
            <div class="row">
                <div class="col-sm-6">
                    <p><?php echo $copyright ;?></p>
                </div>
                <div class="col-sm-6 Reserved">
                    <p><?php echo $reserved ;?></p>
                </div>
            </div>    
        </div>
         <a id="scroll-top"><i class='bx bxs-up-arrow-alt' ></i></a>
    </div>
   
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mb.YTPlayer/3.3.9/jquery.mb.YTPlayer.js"></script>

<!-- Mean Menu JS -->
<script src="<?=URL::to('/themes/giant/andro_files')?>/js/jquery.meanmenu.js"></script>
<!-- Wow JS -->
<script src="<?=URL::to('/themes/giant/andro_files')?>/js/owl.carousel.min.js"></script>

<!-- Smooth Scroll JS -->
<!--<script src="<?=URL::to('/themes/giant/andro_files')?>/js/smoothscroll.min.js"></script>-->

<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?=URL::to('/themes/giant/andro_files')?>/js/bootstrap.min.js"></script>

<!-- Custom JS -->
<script src="<?=URL::to('/themes/giant/andro_files')?>/js/custom.js"></script>

<script type="text/javascript">

    $('.mkdf-video-button-link').on('click', function(){
        var v_id = $(this).attr('href').replace('#', '');
        //console.log(v_id);
        var data_vido = "{videoURL:'https://youtu.be/"+v_id+"',containment:'.video-background', autoPlay:true, startAt:0, opacity:1, frameborder:0}";
        $('.video-background').attr('data-property', data_vido);
        $(".video-background").attr('muted', true);
        $(".video-background").YTPlayer();
    });
    

  $('.tab-content').hide();
    
    $('.tab').click(function(e){
        e.preventDefault();
        $('.tab').removeClass('tab-active');
        $(this).addClass('tab-active');
        var tab_id = $(this).attr('href');
        $('.tab-content').hide();
        $(tab_id).show();
    });
    
    $(function() {
        $('.tab-content:first').each(function (i) {
              $(this).css("display", "block");
              $(this).addClass('tab-active');
        });
        $('.tab:first').each(function (i) {
              $(this).addClass('tab-active');
        });
        $('.team-member:first').each(function (i) {
              $(this).clone().appendTo(".team-detail");
        });
        
        $('.tab-left .accordion:first').each(function (i) {
              $(this).addClass('tab-left-active');
        });
        
        $('.tab-left .accordion-content:first').each(function (i) {
            var data_html = $(this).html();
            $('.preview-tab-data').html(data_html);
        });
        
    });


    // accordion
    $(".accordion").click(function(e) {
        var $this = $(this);
        e.preventDefault();
        if ($this.hasClass("clicked")) {
            $this.removeClass("clicked");
            $this.next().slideUp();
        }
        else {
            $this.addClass("clicked");
            $this.next().slideDown();
        }
    });
    
    $('.accordion').click(function(e){
        e.preventDefault();
        $(this).next().toggleClass('accordion-active');
    });

   $('.footer-link').click( function(){
        if ( $(this).hasClass('current') ) {
            $(this).removeClass('current');
        } else {
            $('.footer-link').removeClass('current');
            $(this).addClass('current');    
        }
    });

    $('#nav-mobile, #close-x').click(function(event) {
    value = $('.sidebar-mobile').css('margin-right') === '-300px' ? '0' : '-300px';
      $('.sidebar-mobile').animate({'margin-right': value});
    }); 
    
    $('.click-pop').on('click', function(){
        $('.popup-form').toggle();
    });
    
    $('#close-form').on('click', function(){
       $('#show_popup_form').css('display', 'none');
    });
    
    $('.close-form-box').on('click', function(){
       $('.popup-form').fadeOut();
    });

    $('.mkdf-video-button-holder').on('click', function(){
        $(this).hide();  
    });  
    
    $('#fotter-1 a[href*=\\#]').on('click',function(e) {
    
        var target = this.hash;
        var $target = $(target);
        console.log(targetname);
        var targetname = target.slice(1, target.length);
    
        if(document.getElementById(targetname) != null) {
             e.preventDefault();
        }
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top-150 //or the height of your fixed navigation 
    
        }, 900, 'swing', function () {
            window.location.hash = target;
      });
    });

    
</script>


<?php if(!isset($_GET['page'])){?>
      

<script>
$(function() {
    $('.btn-outline').click(function(){
        $('html, body').animate({scrollTop : 500},500);
        return false;
    });

    $('.navbar-collapse.collapse ul').hide();
    $('.navbar-expand-sm .navbar-toggler').click(function(){
        $('.navbar-collapse.collapse').toggleClass('show');
    });

    $(window).scroll(function() {
        $( ".fadein" ).each(function(index) {
            var hieghtThreshold = $(this).offset().top-750;
            var scroll = $(window).scrollTop();
            if (scroll >= hieghtThreshold ) {
                $(this).addClass('fadeout');
            } else {
                $(this).removeClass('fadeout');
            }
        });
        
         $( ".fadeinTextup" ).each(function(index) {
            var hieghtThreshold = $(this).offset().top-750;
            var scroll = $(window).scrollTop();
            if (scroll >= hieghtThreshold ) {
                $(this).addClass('fadeinOutup');
            } else {
                $(this).removeClass('fadeinOutup');
            }
        });
        
        $( ".ProfeatuetextIN" ).each(function(index) {
            var hieghtThreshold = $(this).offset().top-750;
            var scroll = $(window).scrollTop();
            if (scroll >= hieghtThreshold ) {
                $(this).addClass('ProfeatuetextOUT');
            } else {
                $(this).removeClass('ProfeatuetextOUT');
            }
        });
        
        
        $( ".textfadein" ).each(function(index) {
            var hieghtThreshold = $(this).offset().top-750;
            var scroll = $(window).scrollTop();
            if (scroll >= hieghtThreshold ) {
                $(this).addClass('textfadeout');
            } else {
                $(this).removeClass('textfadeout');
            }
        });
        
        $( ".feadeProfadein" ).each(function(index) {
            var hieghtThreshold = $(this).offset().top-750;
            var scroll = $(window).scrollTop();
            if (scroll >= hieghtThreshold ) {
                $(this).addClass('feadeProfadeout');
            } else {
                $(this).removeClass('feadeProfadeout');
            }
        });
        
         // this function check if an element is
        // right in window view screen
        function isVisible(el) {
          var $el = $(el),
            above = $el.offset().top - $(window).scrollTop() + $el.outerWidth() < 0,
            below = $el.offset().top > $(window).outerWidth() + $(window).scrollTop();
          return !above && !below;
        }
    
        function loadCards() {
          $('.customCard:not(.is-showing)').each(function(i) {
            var card = $(this);
    
            if (isVisible(card) && !card.hasClass('is-showing')) {
              setTimeout(function() {
                card.addClass('is-showing').offset().top-750;
              }, 70 * (i + 1));
            }
          });
        }
    
        $(window).on('scroll', function() {
          loadCards();
        });
    
        loadCards();
    
    })(jQuery);

    
    $('html, body').stop().animate({
        'scrollTop': $targetEle.offset().top
    }, 0, 'swing', function () {
        window.location.hash = targetEle;
    });
    
});
$(window).scroll(function(){
    if ($(this).scrollTop() > 0) {
       $('.all-lang-2').addClass('newClass');
    } else {
       $('.all-lang-2').removeClass('newClass');
    }
});

</script>

    <?php } ?>   
<!--GET Custome JS-->
<?php if($cur_route_name == 'viewpage'){echo getCustomJS();}?>
<?php } ?>
</body>
</html>