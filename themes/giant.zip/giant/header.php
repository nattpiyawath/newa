<?php
$cur_route_name = Route::current()->getName();
//echo $cur_route_name;
$lang_code = app()->getLocale();

//Check for pagebuilder live edit
if(isset($_GET['lang'])){
    $lang_code = $_GET['lang'];
}
    
?>

<html lang="<?= $lang_code?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?= csrf_token();?>">

    <title>
        <?php
            $seg = Request::segment(2);
            if($cur_route_name == 'viewpage'){
                echo pageTitle().' | Honda Motorcycles';
                $seg = $seg;
            } elseif ($cur_route_name == 'Viewblog'){
                echo blogTitle();
                $seg = 'blog/'.Request::segment(3);
            } else{
                echo 'Motorcycles | N.C.X. Co., Ltd';
            }
        ?>
    </title>

    <!-- Favicon -->
 
    <link rel="shortcut icon" type="image/icon" href="<?=URL::to('/storage/app/uploads')?>/Icon/favicon.png"/>
                
    <!-- Box Icons CSS -->
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/amret.css?v=<?php echo rand(10,5000000); ?>">
         
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/boxicons.min.css">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/meanmenu.css?v=<?php echo rand(10,10000000); ?>">

    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/owl.theme.default.min.css">

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/giant-style.css?v=<?php echo rand(10,3000000); ?>">
    
    <?php if(!isset($_GET['page'])){?>
        <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/animations.css?v=<?php echo rand(10,7000000); ?>">    
    <?php } else{?>
        <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/css-admin.css?v=<?php echo rand(10,78000000); ?>">
    <?php }?>    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/responsive.css?v=<?php echo rand(10,80000000); ?>">
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/custom2.css?v=<?php echo rand(10,90000000); ?>">
    
    <link href='https://fonts.googleapis.com/css?family=Bayon' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css2?family=Odor+Mean+Chey&display=swap" rel="stylesheet">
    <!--GET Custome CSS-->
    <?php if($cur_route_name == 'viewpage'){echo getCustomCSS();}?>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
    
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/myhonda.css?v=<?php echo rand(10,1000); ?>">
    <link rel="stylesheet" href="<?=URL::to('/themes/giant/andro_files')?>/css/main-motor.css?v=<?php echo rand(10,90000000); ?>">
    
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

</head>

<body>


<!-- Navbar -->
<?php
if ($lang_code == 'kh'){?>
<style>
    
</style>
<?php   
    } else{
        ?>
<style>
   .main-nav nav .navbar-nav .nav-item a {font-size: 13px;font-weight: 600;}
   .navbar-light .navbar-nav .nav-link {font-size: 13px;font-weight: 600;}
</style>
<?php   
    }
?>

<div class="navbar-area sticky-top-1">
  
        <!-- Menu Top -->
        <div class="navbar-area sticky-top-1">
              <div class="menu-right top-menu-bar">
            <nav class="navbar navbar-expand-sm container navbar-light">

                <div class="menu-top-logo menu-top-left">
                      <a class="navbar-brand ncx-logo" href="https://www.ncxhonda.com">
                          <img src="<?=url('storage/app/uploads/')?>/logo/We-together-logo-01.png" alt="Logo">
                      </a>
                    </div>


          <div class="navbar-collapse collapse" id="navbarTogglerDemo03">
              

                      <ul class="navbar-nav mr-auto mt-2 mt-lg-0">                    
                       
                        <?php
                        $menu_setting = 'menu_top';
                        $menu_setting = Helper::getSetting($menu_setting); //Get Menu from set Setting
                        $t_id = Helper::getMenu_ID($menu_setting); //Get translate_id
                        
                        $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id); //Get menu by lang_code & translate_id
                        $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                        
                        foreach($navigation as $itemP):?>
                            
                                <li class="nav-item menu">
                                     <a href="<?php echo $itemP->link;?>" class="nav-link "><?php echo $itemP->label;?><span class="caret"></span></a>
                                      <?php 
                                        $child = Helper::getChild($itemP->id);
                                        if(!$child->isEmpty()):
                                      ?>
                                          <ul class="dropdown-menu">
                                            <?php foreach($child as $item2):?>
                                              <li class="nav-item">
                                                <a href="<?php echo $item2['link'];?>" class="nav-link dropdown-toggle">
                                                  <?php echo $item2['label'];?><span class="caret"></span></a>
                                                  
                                                    <?php 
                                                        $child2 = Helper::getChild($item2->id);
                                                        if(!$child2->isEmpty()):
                                                     ?>
                                                          <ul class="dropdown-menu">
                                                            <?php foreach($child2 as $item3):?>
                                                              <li class="nav-item">
                                                                <a href="<?php echo $item3['link'];?>" class="nav-link dropdown-toggle">
                                                                  <?php echo $item3['label'];?><span class="caret"></span></a>
                                                              </li>
                                                            <?php endforeach; ?>
                                                          </ul>
                                                    <?php endif;?>
                                                  
                                              </li>
                                            <?php endforeach; ?>
                                          </ul>
                                       <?php endif;?>
                               </li>
    
                        <?php endforeach; ?>
                         <div class="all-lang">
                    <?php

                    $lang = Helper::langList();
                    $current_lang = $lang_code;
                    
                    foreach ($lang as $lg):
                    $language_code = $lg->lang_code;?>
                   
                       <li class="language gf-lang <?php if ($current_lang == $language_code){ echo 'active-language';}?>">
                                <a href="<?=URL('').'/'.$lg->lang_code.'/'.Request::segment(2)?>" class="nav-link"><?=$lg->lang_name?></a>
                       </li>
                      
                    <?php endforeach;?>
                 </div> 
                      </ul>
                    </div>
            <div class="menu-top-logo" style="float:right;">
                      <a class="navbar-brand top-hongda-logo" href="<?=url($lang_code.'/home')?>">
                          <img src="<?=url('storage/app/uploads/')?>/logo/logo-honda-top.jpg" alt="Logo">
                      </a>
                    </div>
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
                
            </div>
              
        </div>
        <!-- En Menu Top -->

  <!-- Menu For Desktop Device -->
  <div class="main-nav three">
      <div class="container">
        
            <nav class="navbar navbar-expand-sm   navbar-light">

                 <div class="menu-left">
                      <a class="navbar-brand main-hongda-logo" href="<?=url($lang_code.'/home')?>">
                          <img src="<?=url('storage/app/uploads/')?>/logo/logo-honda.png" alt="Logo">
                      </a>
                    </div>
            <div class="all-lang-2 " style="display:none;">
                      <ul>
                    <?php

                    $lang = Helper::langList();
                    $current_lang = $lang_code;
                    
                    foreach ($lang as $lg):
                    $language_code = $lg->lang_code;?>
                   
                       <li class="language gf-lang <?php if ($current_lang == $language_code){ echo 'active-language-2';}?>">
                                <a href="<?=URL('').'/'.$lg->lang_code.'/'.Request::segment(2)?>" class="nav-link"><?=$lg->lang_name?></a>
                       </li>
                      
                    <?php endforeach;?>
                    </ul>
                 </div> 
          <div class="collapse navbar-collapse" id="navbarTogglerDemo04">
                        <ul class="navbar-nav">                    
                   
                    <?php
                    $menu_setting = 'menu';
                    $menu_setting = Helper::getSetting($menu_setting); //Get Menu from set Setting
                    $t_id = Helper::getMenu_ID($menu_setting); //Get translate_id
                    
                    $menu_by_lang_and_id = Helper::getMenu_Translated($lang_code, $t_id); //Get menu by lang_code & translate_id
                    $navigation = Helper::getParentMenu($menu_by_lang_and_id);
                    
                    foreach($navigation as $itemP):?>
                        
                            <li class="nav-item menu">
                                 <a href="<?php echo $itemP->link;?>" class="nav-link dropdown-toggle"><?php echo $itemP->label;?><span class="caret"></span></a>
                                  <?php 
                                    $child = Helper::getChild($itemP->id);
                                    if(!$child->isEmpty()):
                                  ?>
                                      <ul class="dropdown-menu">
                                        <?php foreach($child as $item2):?>
                                          <li class="nav-item">
                                            <a href="<?php echo $item2['link'];?>" class="nav-link dropdown-toggle">
                                              <?php echo $item2['label'];?><span class="caret"></span></a>
                                              
                                                <?php 
                                                    $child2 = Helper::getChild($item2->id);
                                                    if(!$child2->isEmpty()):
                                                 ?>
                                                      <ul class="dropdown-menu">
                                                        <?php foreach($child2 as $item3):?>
                                                          <li class="nav-item">
                                                            <a href="<?php echo $item3['link'];?>" class="nav-link dropdown-toggle">
                                                              <?php echo $item3['label'];?><span class="caret"></span></a>
                                                          </li>
                                                        <?php endforeach; ?>
                                                      </ul>
                                                <?php endif;?>
                                              
                                          </li>
                                        <?php endforeach; ?>
                                      </ul>
                                   <?php endif;?>
                           </li>

                    <?php endforeach; ?>
                    
                    
                <div class="main-menu-rigt">
                    <div class="media-mobile">
                        <li class="nav-item language gf-lang"><a href="https://www.facebook.com/hondamotorcyclecambodia" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                        <li class="nav-item language gf-lang"><a href="https://www.instagram.com/hondacambodiancx/" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                        <li class="nav-item language gf-lang"><a href="https://www.youtube.com/Thehondancx" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                        <span class="nav-item language gf-lang"><a href="https://www.tiktok.com/@hondacambodiancx" target="_blank">
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.896" height="22.755" viewBox="0 0 19.896 22.755">
  <path id="Icon_simple-tiktok" data-name="Icon simple-tiktok" d="M12.293.018C13.48,0,14.658.009,15.836,0a5.645,5.645,0,0,0,1.586,3.779A6.391,6.391,0,0,0,21.265,5.4V9.054a9.7,9.7,0,0,1-3.806-.879,11.2,11.2,0,0,1-1.468-.843c-.009,2.646.009,5.293-.018,7.93a6.922,6.922,0,0,1-1.223,3.571,6.752,6.752,0,0,1-5.356,2.909,6.608,6.608,0,0,1-3.7-.933,6.834,6.834,0,0,1-3.308-5.175c-.018-.453-.027-.906-.009-1.35A6.823,6.823,0,0,1,10.29,8.229c.018,1.341-.036,2.683-.036,4.024a3.109,3.109,0,0,0-3.969,1.921,3.6,3.6,0,0,0-.127,1.459,3.084,3.084,0,0,0,3.172,2.6,3.045,3.045,0,0,0,2.51-1.459,2.091,2.091,0,0,0,.372-.961c.091-1.622.054-3.235.063-4.858.009-3.652-.009-7.3.018-10.939Z" transform="translate(-1.869 0.504)" fill="none" stroke="#000" stroke-width="1"/>
</svg>
</div>
</div>

                  </ul>
                    </div>
        
           <div class="main-menu-rigt">
                    <ul class="media-desktop">
                        <li class="nav-item language gf-lang"><a href="https://www.facebook.com/hondamotorcyclecambodia" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                        <li class="nav-item language gf-lang"><a href="https://www.instagram.com/hondacambodiancx/" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                        <li class="nav-item language gf-lang"><a href="https://www.youtube.com/Thehondancx" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                        <span class="nav-item language gf-lang"><a href="https://www.tiktok.com/@hondacambodiancx" target="_blank">
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.896" height="22.755" viewBox="0 0 19.896 22.755">
  <path id="Icon_simple-tiktok" data-name="Icon simple-tiktok" d="M12.293.018C13.48,0,14.658.009,15.836,0a5.645,5.645,0,0,0,1.586,3.779A6.391,6.391,0,0,0,21.265,5.4V9.054a9.7,9.7,0,0,1-3.806-.879,11.2,11.2,0,0,1-1.468-.843c-.009,2.646.009,5.293-.018,7.93a6.922,6.922,0,0,1-1.223,3.571,6.752,6.752,0,0,1-5.356,2.909,6.608,6.608,0,0,1-3.7-.933,6.834,6.834,0,0,1-3.308-5.175c-.018-.453-.027-.906-.009-1.35A6.823,6.823,0,0,1,10.29,8.229c.018,1.341-.036,2.683-.036,4.024a3.109,3.109,0,0,0-3.969,1.921,3.6,3.6,0,0,0-.127,1.459,3.084,3.084,0,0,0,3.172,2.6,3.045,3.045,0,0,0,2.51-1.459,2.091,2.091,0,0,0,.372-.961c.091-1.622.054-3.235.063-4.858.009-3.652-.009-7.3.018-10.939Z" transform="translate(-1.869 0.504)" fill="none" stroke="#000" stroke-width="1"/>
</svg>

                        </a></span>

                        
                    </ul>
                  
          </div>
           <div class="nav-item search side-nav">
                          <div class="nav-search">
                              <i id="search-btn" class="bx bx-search-alt"></i>
                              <div id="search-overlay" class="block">
                                  <div class="centered">
                                      <div id="search-box">
                                          <i id="close-btn" class="bx bx-x"></i>
                                          <form>
                                              <input type="text" class="form-control" placeholder="Search..."/>
                                              <button type="submit" class="btn">Search</button>
                                          </form>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
          <button class="navbar-toggler mobile" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo04" aria-controls="navbarTogglerDemo04" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
    </nav>
       
      </div>
  </div>
</div>
<!-- End Navbar -->
