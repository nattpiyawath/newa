<?php 

if (isset($_GET['page'])){
   echo '<h1>Branch Location</h1>';
} 

else{ 
$currentLocale = app()->getLocale();
?>

<style type="text/css">

    label.selectbox {
        margin-right: 10px;
        color: #163f99;
    }
    input#reset_state {
        padding: 3px 24px;
        margin-left: 30px;
        border: 1px solid #a7a7a7;
    }
    select#type {
        padding: 6px 6px;
        border: 1px solid #a7a7a7;
    }
    
    #map-canvas {width: 100%;height: 500px;}
    .gm-style-iw-c{max-width: 350px!important;}
    hr {
        margin-top: 10px;
        margin-bottom: 10px;
        border: 0;
        border-top: 1px solid #eee;
    }
    span.map-marker {
        display: inline-flex;
        margin-bottom: 14px;
        line-height: 20px;
    }
    span.map-marker i.fas {
        padding: 5px 10px 0 0;
        color: #163f98;
    }
    span.head-label {
        color: black !important;
        font-weight: bolder;
        display: contents;
    }
    button.gm-ui-hover-effect {
        margin: 10px !important;
    }
</style>

<form class="form-inline" style="margin: 0 0 20px">
        <label class="selectbox" for="location_select_list"><?php if($currentLocale == 'kh'){echo'ស្វែងរកតាមតំបន់';}else{echo 'Locator';}?> </label><label id="side_bar" class="">

        <select id="type" onchange="filterMarkers(this.value);">
                   <option value="" lat="" long=""><?php if($currentLocale == 'kh'){echo'ជ្រើសរើសទីតាំង';}else{echo 'Select Province';}?></option>
                	<option value="2" lat="12.9256791" long="103.23171364"><?php if($currentLocale == 'kh'){echo'បាត់ដំបង';}else{echo 'Battambang';}?></option>
                	<option value="3" lat="12.00708458" long="105.37811279"><?php if($currentLocale == 'kh'){echo'កំពង់ចាម';}else{echo 'Kampong Cham';}?></option>
                	<option value="4" lat="12.24339151" long="104.71343994"><?php if($currentLocale == 'kh'){echo'កំពង់ឆ្នាំង';}else{echo 'Kampong Chhnang';}?></option>
                	<option value="5" lat="11.56748917" long="104.2691803"><?php if($currentLocale == 'kh'){echo'កំពង់ស្ពឺ';}else{echo 'Kampong Speu';}?></option>
                	<option value="6" lat="12.81715766" long="104.98397827"><?php if($currentLocale == 'kh'){echo'កំពង់ធំ';}else{echo 'Kampong Thom';}?></option>
                	<option value="7" lat="10.76579845" long="104.31350361"><?php if($currentLocale == 'kh'){echo'កំពត';}else{echo 'Kampot';}?></option>
                	<option value="8" lat="11.39459395" long="105.01840978"><?php if($currentLocale == 'kh'){echo'កណ្តាល';}else{echo 'Kandal';}?></option>
                	<option value="16" lat="11.5730391" long="104.857807"><?php if($currentLocale == 'kh'){echo'ភ្នំពេញ';}else{echo 'Phnom Penh';}?></option>
                	<option value="18" lat="11.4856226" long="105.3363606"><?php if($currentLocale == 'kh'){echo'ព្រៃវែង';}else{echo 'Prey Veng';}?></option>
                	<option value="20" lat="13.9311155" long="107.0391499"><?php if($currentLocale == 'kh'){echo'រតនៈគីរី';}else{echo 'Ratanak Kiri';}?></option>
                	<option value="21" lat="13.3719067" long="103.99265045"><?php if($currentLocale == 'kh'){echo'សៀមរៀប';}else{echo 'Siem Reap';}?></option>
                	<option value="23" lat="11.080095" long="105.7974874"><?php if($currentLocale == 'kh'){echo'ស្វាវរៀង';}else{echo 'Svay Rieng';}?></option>
                	<option value="24" lat="10.93539205" long="104.789883"><?php if($currentLocale == 'kh'){echo'តាកែវ';}else{echo 'Takeo';}?></option>
                	<option value="25" lat="11.7513041" long="105.0044197"><?php if($currentLocale == 'kh'){echo'ព្រែកតាមាក់';}else{echo 'Preaek Ta Meak';}?></option>
        </select>


        </label>
        <input class="btn-reset-map" type="reset" id="reset_state" value="<?php if($currentLocale == 'kh'){echo'កំណត់ឡើងវិញ';}else{echo 'Reset';}?>" onclick="initialize();">
                                        					
    </form>
    

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAc75-rjAtjcViwQqzOjqXsZNuIgkLpIzM&sensor=false&callback=initialize"></script>

<div id="map-canvas"></div><br><br>


<script type="text/javascript">
                                        
                                    var gmarkers1 = [];
                                    var markers1 = [];
                                    var infowindow = new google.maps.InfoWindow({
                                        content: ''
                                    });
                                    
                                    // Our markers
                                    markers1 = [
                                            
                                                <?php 
                                                $data = getAll_Branches();
                                                $i = 0;
                                                
                                                foreach ($data as $item): ?>

                                                    ['<?php print $i?>', '<?php print $item['title'].'<hr> <span class="map-marker"><i class="fas fa-map-marker-alt"></i> <span class="head-label"> Address: </span><br> '.$item['address'].'</span><br> <span class="map-marker"><i class="fas fa-mobile-alt"></i> <span class="head-label">Contact Phone: </span><br> '.$item['number'].'</span><br> <span class="map-marker">'; $email = $item['email']; if(!empty($email)){ print'<i class="fas fa-envelope-open"></i> <span class="head-label">Email: </span><br>'.$item['email']; }?>', <?php print $item['latitude'] ?>, <?php print $item['longitude'] ?>, '<?php print $item['province'] ?>', '<?php print $item['title']?>'],
                                                     
                                                <?php 
                                                $i++;
                                                endforeach; ?>
                                            
                                    ];
                                    
                                    /**
                                     * Function to init map
                                     */
                                    
                                    function initialize() {
                                        var center = new google.maps.LatLng(12.5223906, 104.81506348);
                                        var mapOptions = {
                                            zoom: 7,
                                            center: center,
                                            mapTypeId: google.maps.MapTypeId.roadmap
                                        };
                                    
                                        map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
                                        for (i = 0; i < markers1.length; i++) {
                                            addMarker(markers1[i]);
                                        }
                                    }
                                    
                                    /**
                                     * Function to add marker to map
                                     */
                                    
                                    function addMarker(marker) {
                                        var category = marker[4];
                                        var title = marker[5];
                                        var pos = new google.maps.LatLng(marker[2], marker[3]);
                                        var content = marker[1];
                                    
                                        marker1 = new google.maps.Marker({
                                            title: title,
                                            position: pos,
                                            icon: '<?=myUpload()?>amret-marker3.png',
                                            category: category,
                                            map: map
                                        });
                                    
                                        gmarkers1.push(marker1);
                                        
                                        function toggleBounce() {
                                            map.setZoom(10);
                                        }
                                    
                                        // Marker click listener
                                        google.maps.event.addListener(marker1, 'click', (function (marker1, content) {
                                            return function () {
                                                //console.log('Gmarker 1 gets pushed');
                                                infowindow.setContent(content);
                                                infowindow.open(map, marker1);
                                                map.panTo(this.getPosition());
                                                map.setZoom(9);
                                                setTimeout(toggleBounce, 100);
                                            }
                                        })(marker1, content));
                                    }
                                    
                                    /**
                                     * Function to filter markers by category
                                     */
                                    
                                    filterMarkers = function (category) {
                                        var center = new google.maps.LatLng(12.5223906, 104.81506348);
                                        var mapOptions = {
                                            zoom: 1,
                                            center: center,
                                            mapTypeId: google.maps.MapTypeId.roadmap
                                        };
                                        
                                       var bounds = new google.maps.LatLngBounds();
                                        infowindow.close();
                                        
                                        for (i = 0; i < gmarkers1.length; i++) {
                                            marker = gmarkers1[i];
                                            // If is same category or category not picked
                                            if (marker.category == category || category.length === 0) {
                                                marker.setVisible(true);
                                                bounds.extend(marker.getPosition());
                                                map.fitBounds(bounds);
                                                map.setZoom(8);
                                            }
                                            // Categories don't match 
                                            else {
                                                marker.setVisible(false);
                                                map.setZoom(center);
                                            }
                                            
                                            
                                        }
                                    }
                                    
                                    // Init map
                                    initialize();

                            </script>
    
<?php }?>