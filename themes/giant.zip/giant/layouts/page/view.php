<?php require(base_path().'/themes/giant/header.php'); ?>


<?= $body ?>

<?php require(base_path().'/themes/giant/footer.php'); ?>