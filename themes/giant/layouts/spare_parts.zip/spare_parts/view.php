<?php require(base_path().'/themes/giant/header.php'); ?>

<style type="text/css">
	@media screen and (min-width: 1800px){
		.page-title-area {height: 400px;}
	}
</style>

<div class="page-title-area title-bg-one">
   <div class="title-shape">

   <div class="d-table">
      <div class="d-table-cell">
         <div class="container">
            <div class="title-content">
               <h2><?php echo pageTitle();?></h2>
               <ul>
                  <li>
                     <a href="index.html">Home</a>
                  </li>
                  <li>
                     <i class="bx bx-chevron-right"></i>
                  </li>
                  <li>
                     <span><?php echo pageTitle();?></span>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>

    <div class="details-item" phpb-blocks-container><?= $body ?></div>
<div class="container mt-5">
  <div class="row">
        <div class="col-sm-12" style="padding:0;">
             
             <div class="col-sm-3 be4-merchant">
                <div class="input-group">
    				<input type="text" name="keyword" class="form-control" placeholder="Search">
    				<input type="hidden" name="lang" value="en">
    				<span class="input-group-btn">
    				<button type="button" class="btn  btn-default" data-target="#search_form" data-toggle="collapse" aria-label="Close" aria-expanded="true"><i class="zmdi zmdi-search"></i></button>
    				</span>
    			</div>
    		  </div>
    		  
    		  <div class="col-sm-3 be4-merchant">
                <select class="form-control" data-placeholder="Merchant's Category" name="merchant_cate_id">
                                    
                    <option value="0">Select Categories</option>
                    <option value="shop">Shop</option>
                    <option value="fashion-store">Fashion Store</option>
                    <option value="cafe-shop">Cafe Shop</option>

                </select>
    		  </div>
    		  
    		  <div class="col-sm-3 be4-merchant">
                <select class="form-control" data-placeholder="Merchant's Category" name="merchant_cate_id">
                                    
                    <option value="0">Select Discount(%)</option>
                    <option value="10">10%</option>
                    <option value="20">20%</option>
                    <option value="30">30%</option>
                    <option value="40">40%</option>

                </select>
    		  </div>
    		 
    		  <div class="col-sm-3 be4-merchant">
                <select class="form-control" data-placeholder="Merchant's Category" name="merchant_cate_id">
                                    
                    <option value="0">Select Region</option>
                    <option value="1">Phnom Penh</option>
                    <option value="2">Siem Reap</option>
                    <option value="3">Kompong Som</option>
                    <option value="4">Keb</option>

                </select>
    		  </div>
            
        </div>
        
        <div class="col-sm-12" style="padding:0;">
            
            <hr class="light-grey-hr">
    
        <h1 class="title-cate-merchant"> Cafe & Restaurants </h1>
        </div>

<?php

$lang = Helper::getSparts();
// // echo $lang;
// $url = myUpload(); 

foreach ($lang as $value) {?>
    <div class="col-sm-2 list-items" style="padding:0;">
        <div class="card p-3">

        <h4 class="blog-title"><?php echo $value->title; ?></h4>

            <div class="d-flex flex-row mb-3">
                <img src="<?php echo $value->thumbnail ;?>" alt="Shape">
            </div>
            
            
        </div>
        
        <div class="card-body content-promotion">
            
        </div>
        
    </div>

   <?php } ?> 

</div>

</div>


<?php require(base_path().'/themes/giant/footer.php'); ?>