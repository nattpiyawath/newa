@extends('template')

@section('content')
    <h3>{{$project->pro_title}}</h3>
    <p>{{$project->pro_remark}}</p>
@endsection