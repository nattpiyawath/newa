@extends('template')
@section('title', 'Add Specification')
@section('content')
<style type="text/css">
   textarea.form-control {height: 80px;}
   .card-view {max-width: 1280px;margin: 0 auto;}
   .ck-editor__editable {min-height: 200px;}
   .checkbox input[type="checkbox"]{opacity: 1;position: unset;margin-left: 0;}
</style>
<div class="row">
   <div class="col-md-12">
      <div class="panel panel-default card-view">
         <div class="panel-heading">
            <div class="pull-left">
               <h6 class="panel-title txt-dark">Add Specification</h6>
            </div>
            <div class="clearfix"></div>
         </div>
         <div class="panel-wrapper collapse in">
            <div class="panel-body">
               <div class="row">
                  <div class="col-sm-12 col-xs-12">
                     <div class="form-wrap">
                        {!! Form::open(['route' => 'specification.store']) !!}
                        <input type="hidden" name="lang_code" value="{{$lang}}">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label for="page-status">Status</label>
                                    <select class="form-control" data-placeholder="Status" name="is_published">
                                       <option value="0" selected>Draft</option>
                                       <option value="1">Publish</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label for="select-country">Translate Of </label>
                                    <select class="form-control selectpicker" id="select-page" data-live-search="true" name="translate_id">
                                       
                                        <option value="0">Select...</option>
                                        
                                    </select>

                                    <script type="text/javascript">
                                            $(function() {
                                                $('.selectpicker').selectpicker();
                                            });

                                    </script>
                                 </div>
                              </div>

                              <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Select Page</label>
                                    <select class="form-control" data-placeholder="Spare Part's Category" name="page_id">
                                        
                                    <option value="0">Select...</option>

                                    </select>

                                </div>
                              </div>

                              <div class="col-md-3">
                                 <div class="form-group">
                                    <div class="form-actions mt-10" style="text-align: right;">
                                       <a class="btn btn-default btn-close" href="{{url('admin/specification?lang='.$lang)}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back</a>
                                       {{ Form::button('<i class="fa fa-floppy-o" aria-hidden="true"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success mr-10'] )  }}
                                    </div>
                                 </div>
                              </div>
                              <!--/span-->
                           </div>
                        </div>
                        <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Model Code</h6>
                        <hr class="light-grey-hr">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="form-group @if($errors->has('code')) has-error @endif">
                                 <label class="control-label mb-10">Model Code</label>
                                 <input type="text" class="form-control" name="code" value="{{ old('code') }}" placeholder="Model Code" />
                                 @if ($errors->has('code'))
                                 <span class="help-block">{!! $errors->first('code') !!}</span>
                                 @endif
                              </div>
                           </div>
                        </div>
                     </div>

                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Engine</h6>
                     <hr class="light-grey-hr">
                     <div class="row">
                            <div class="col-md-3">
                              <div class="form-group @if($errors->has('engine')) has-error @endif">
                                 <label class="control-label mb-10">Engine System</label>
                                 <input type="text" class="form-control" name="engine" value="{{ old('engine') }}" placeholder="Engine System" />
                                 @if ($errors->has('engine'))
                                 <span class="help-block">{!! $errors->first('engine') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('bore')) has-error @endif">
                                 <label class="control-label mb-10">Bore and Stroke</label>
                                 <input type="text" class="form-control" name="bore" value="{{ old('bore') }}" placeholder="Bore and Stroke" />
                                 @if ($errors->has('bore'))
                                 <span class="help-block">{!! $errors->first('bore') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('displacement')) has-error @endif">
                                 <label class="control-label mb-10">Displacement</label>
                                 <input type="text" class="form-control" name="displacement" value="{{ old('displacement') }}" placeholder="Displacement" />
                                 @if ($errors->has('displacement'))
                                 <span class="help-block">{!! $errors->first('displacement') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('fuel')) has-error @endif">
                                 <label class="control-label mb-10">Fuel System</label>
                                 <input type="text" class="form-control" name="fuel" value="{{ old('fuel') }}" placeholder="Fuel System" />
                                 @if ($errors->has('fuel'))
                                 <span class="help-block">{!! $errors->first('fuel') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('fuel_type')) has-error @endif">
                                 <label class="control-label mb-10">Fuel Type</label>
                                 <input type="text" class="form-control" name="fuel_type" value="{{ old('fuel_type') }}" placeholder="Fuel Type" />
                                 @if ($errors->has('fuel_type'))
                                 <span class="help-block">{!! $errors->first('fuel_type') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('ignition')) has-error @endif">
                                 <label class="control-label mb-10">Ignition System</label>
                                 <input type="text" class="form-control" name="ignition" value="{{ old('ignition') }}" placeholder="Ignition System" />
                                 @if ($errors->has('ignition'))
                                 <span class="help-block">{!! $errors->first('ignition') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('final_drive')) has-error @endif">
                                 <label class="control-label mb-10">Final Drive Type</label>
                                 <input type="text" class="form-control" name="final_drive" value="{{ old('final_drive') }}" placeholder="Final Drive Type" />
                                 @if ($errors->has('final_drive'))
                                 <span class="help-block">{!! $errors->first('final_drive') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('clutch')) has-error @endif">
                                 <label class="control-label mb-10">Clutch System</label>
                                 <input type="text" class="form-control" name="clutch" value="{{ old('clutch') }}" placeholder="Clutch System" />
                                 @if ($errors->has('clutch'))
                                 <span class="help-block">{!! $errors->first('clutch') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('starter')) has-error @endif">
                                 <label class="control-label mb-10">Starter System</label>
                                 <input type="text" class="form-control" name="starter" value="{{ old('starter') }}" placeholder="Starter System" />
                                 @if ($errors->has('starter'))
                                 <span class="help-block">{!! $errors->first('starter') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('compression')) has-error @endif">
                                 <label class="control-label mb-10">Compression Ratio</label>
                                 <input type="text" class="form-control" name="compression" value="{{ old('compression') }}" placeholder="Compression Ratio" />
                                 @if ($errors->has('compression'))
                                 <span class="help-block">{!! $errors->first('compression') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('oil_capacity')) has-error @endif">
                                 <label class="control-label mb-10">Engine oil capacity</label>
                                 <input type="text" class="form-control" name="oil_capacity" value="{{ old('oil_capacity') }}" placeholder="Engine oil capacity" />
                                 @if ($errors->has('oil_capacity'))
                                 <span class="help-block">{!! $errors->first('oil_capacity') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('transmission')) has-error @endif">
                                 <label class="control-label mb-10">Transmission</label>
                                 <input type="text" class="form-control" name="transmission" value="{{ old('transmission') }}" placeholder="Transmission" />
                                 @if ($errors->has('transmission'))
                                 <span class="help-block">{!! $errors->first('transmission') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('oil_replace')) has-error @endif">
                                 <label class="control-label mb-10">Oil replacement</label>
                                 <input type="text" class="form-control" name="oil_replace" value="{{ old('oil_replace') }}" placeholder="Oil replacement" />
                                 @if ($errors->has('oil_replace'))
                                 <span class="help-block">{!! $errors->first('oil_replace') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('gearshift')) has-error @endif">
                                 <label class="control-label mb-10">Gearshift pattern</label>
                                 <input type="text" class="form-control" name="gearshift" value="{{ old('gearshift') }}" placeholder="Gearshift pattern" />
                                 @if ($errors->has('gearshift'))
                                 <span class="help-block">{!! $errors->first('gearshift') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('reduction')) has-error @endif">
                                 <label class="control-label mb-10">(Primary reduction/Final reduction)</label>
                                 <input type="text" class="form-control" name="reduction" value="{{ old('reduction') }}" placeholder="Primary reduction/Final reduction" />
                                 @if ($errors->has('reduction'))
                                 <span class="help-block">{!! $errors->first('reduction') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('ratio')) has-error @endif">
                                 <label class="control-label mb-10">Gear ratio : 1st</label>
                                 <input type="text" class="form-control" name="ratio" value="{{ old('ratio') }}" placeholder="Gear ratio : 1st" />
                                 @if ($errors->has('ratio'))
                                 <span class="help-block">{!! $errors->first('ratio') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio1')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 2nd</label>
                                 <input type="text" class="form-control" name="radio1" value="{{ old('radio1') }}" placeholder="Gear radio : 2nd" />
                                 @if ($errors->has('radio1'))
                                 <span class="help-block">{!! $errors->first('radio1') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio2')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 3rd</label>
                                 <input type="text" class="form-control" name="radio2" value="{{ old('radio2') }}" placeholder="Gear radio : 3rd" />
                                 @if ($errors->has('radio2'))
                                 <span class="help-block">{!! $errors->first('radio2') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('radio3')) has-error @endif">
                                 <label class="control-label mb-10">Gear radio : 4th</label>
                                 <input type="text" class="form-control" name="radio3" value="{{ old('radio3') }}" placeholder="Gear radio : 4th" />
                                 @if ($errors->has('radio3'))
                                 <span class="help-block">{!! $errors->first('radio3') !!}</span>
                                 @endif
                              </div>
                           </div>
                     </div>

                     <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Dimensions</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('wlh')) has-error @endif">
                                 <label class="control-label mb-10">[W x L x H]</label>
                                 <input type="text" class="form-control" name="wlh" value="{{ old('wlh') }}" placeholder="[W x L x H]" />
                                 @if ($errors->has('wlh'))
                                 <span class="help-block">{!! $errors->first('wlh') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('wheelbase')) has-error @endif">
                                 <label class="control-label mb-10">Wheelbase</label>
                                 <input type="text" class="form-control" name="radio2" value="{{ old('wheelbase') }}" placeholder="Wheelbase " />
                                 @if ($errors->has('wheelbase'))
                                 <span class="help-block">{!! $errors->first('wheelbase') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('weight')) has-error @endif">
                                 <label class="control-label mb-10">Weight</label>
                                 <input type="text" class="form-control" name="weight" value="{{ old('weight') }}" placeholder="Weight" />
                                 @if ($errors->has('weight'))
                                 <span class="help-block">{!! $errors->first('weight') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('ground')) has-error @endif">
                                 <label class="control-label mb-10">Ground Clearance</label>
                                 <input type="text" class="form-control" name="ground" value="{{ old('ground') }}" placeholder="Ground Clearance" />
                                 @if ($errors->has('ground'))
                                 <span class="help-block">{!! $errors->first('ground') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('seat')) has-error @endif">
                                 <label class="control-label mb-10">Seat High</label>
                                 <input type="text" class="form-control" name="seat" value="{{ old('seat') }}" placeholder="Seat High" />
                                 @if ($errors->has('seat'))
                                 <span class="help-block">{!! $errors->first('seat') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('fuel_tank')) has-error @endif">
                                 <label class="control-label mb-10">Fuel Tank</label>
                                 <input type="text" class="form-control" name="fuel_tank" value="{{ old('fuel_tank') }}" placeholder="Fuel Tank" />
                                 @if ($errors->has('fuel_tank'))
                                 <span class="help-block">{!! $errors->first('fuel_tank') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('caster')) has-error @endif">
                                 <label class="control-label mb-10">Caster Angle/Trail</label>
                                 <input type="text" class="form-control" name="caster" value="{{ old('caster') }}" placeholder="Caster Angle/Trail" />
                                 @if ($errors->has('caster'))
                                 <span class="help-block">{!! $errors->first('caster') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('frame')) has-error @endif">
                                 <label class="control-label mb-10">Frame Type</label>
                                 <input type="text" class="form-control" name="frame" value="{{ old('frame') }}" placeholder="Frame" />
                                 @if ($errors->has('frame'))
                                 <span class="help-block">{!! $errors->first('frame') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group @if($errors->has('battery')) has-error @endif">
                                 <label class="control-label mb-10">Battery</label>
                                 <input type="text" class="form-control" name="battery" value="{{ old('battery') }}" placeholder="Battery" />
                                 @if ($errors->has('battery'))
                                 <span class="help-block">{!! $errors->first('battery') !!}</span>
                                 @endif
                              </div>
                           </div>

                     </div>

                     <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Suspension & Tire</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                            <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_front')) has-error @endif">
                                 <label class="control-label mb-10">Tire Size Front</label>
                                 <input type="text" class="form-control" name="tire_front" value="{{ old('tire_front') }}" placeholder="Tire Size Front" />
                                 @if ($errors->has('tire_front'))
                                 <span class="help-block">{!! $errors->first('tire_front') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_rear')) has-error @endif">
                                 <label class="control-label mb-10">Tire Size Rear</label>
                                 <input type="text" class="form-control" name="tire_rear" value="{{ old('tire_rear') }}" placeholder="Tire Size Rear" />
                                 @if ($errors->has('tire_rear'))
                                 <span class="help-block">{!! $errors->first('tire_rear') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('front_brake')) has-error @endif">
                                 <label class="control-label mb-10">Front brake</label>
                                 <input type="text" class="form-control" name="front_brake" value="{{ old('front_brake') }}" placeholder="Front brake" />
                                 @if ($errors->has('front_brake'))
                                 <span class="help-block">{!! $errors->first('front_brake') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('rear_brake')) has-error @endif">
                                 <label class="control-label mb-10">Rear brake</label>
                                 <input type="text" class="form-control" name="rear_brake" value="{{ old('rear_brake') }}" placeholder="Rear brake" />
                                 @if ($errors->has('rear_brake'))
                                 <span class="help-block">{!! $errors->first('rear_brake') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('tire_type')) has-error @endif">
                                 <label class="control-label mb-10">Tire Type</label>
                                 <input type="text" class="form-control" name="tire_type" value="{{ old('tire_type') }}" placeholder="Tire Type" />
                                 @if ($errors->has('tire_type'))
                                 <span class="help-block">{!! $errors->first('tire_type') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('suspension')) has-error @endif">
                                 <label class="control-label mb-10">Suspension Front</label>
                                 <input type="text" class="form-control" name="suspension" value="{{ old('suspension') }}" placeholder="Suspension Front" />
                                 @if ($errors->has('suspension'))
                                 <span class="help-block">{!! $errors->first('suspension') !!}</span>
                                 @endif
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group @if($errors->has('suspension_rear')) has-error @endif">
                                 <label class="control-label mb-10">Suspension Rear</label>
                                 <input type="text" class="form-control" name="suspension_rear" value="{{ old('suspension_rear') }}" placeholder="Suspension Rear" />
                                 @if ($errors->has('suspension_rear'))
                                 <span class="help-block">{!! $errors->first('suspension_rear') !!}</span>
                                 @endif
                              </div>
                           </div>

                     <input type="hidden" name="lang_code" value="{{$lang}}">

                  </div>

                  <br>
                     <h6 class="txt-dark capitalize-font"><i class="fa fa-info" aria-hidden="true"></i> Spare Part</h6>
                     <hr class="light-grey-hr">
                     <div class="row">

                            <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">Honda Smart Technology</label>
                                    <select class="form-control" data-placeholder="Honda Smart Technology" name="hst">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">PGM-FI</label>
                                    <select class="form-control" data-placeholder="PGM-FI" name="pgm">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">ESP</label>
                                    <select class="form-control" data-placeholder="ESP" name="esp">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">ESP Plus</label>
                                    <select class="form-control" data-placeholder="ESP Plus" name="esp_plus">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">A Idling</label>
                                    <select class="form-control" data-placeholder="A Idling" name="idling">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                    <label for="page-status">Combi Brake</label>
                                    <select class="form-control" data-placeholder="Combi Brake" name="combi">
                                       <option value="0" selected>No</option>
                                       <option value="1">Yes</option>
                                    </select>
                              </div>
                           </div>

                     <input type="hidden" name="lang_code" value="{{$lang}}">

                  </div>
               

               </div>
               {!! Form::close() !!}
            </div>
         </div>
      </div>
   </div>
</div>
</div>      
</div>
</div>
@endsection