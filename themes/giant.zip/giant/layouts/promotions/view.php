<?php require(base_path().'/themes/giant/header.php'); ?>

<div class="page-title-area title-bg-one">
   <div class="title-shape">
      <img src="<?= myUpload().getImageheader($lang);?>" alt="Shape">
   </div>
   <div class="d-table">
      <div class="d-table-cell">
         <div class="container">
            <div class="title-content">
               <h2><?php echo pageTitle();?></h2>
               <ul>
                  <li>
                     <a href="index.html">Home</a>
                  </li>
                  <li>
                     <i class="bx bx-chevron-right"></i>
                  </li>
                  <li>
                     <span><?php echo pageTitle();?></span>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</div>



<style type="text/css">

	@media screen and (min-width: 1800px){
		.page-title-area {height: 400px;}
	}
	
	.blog-post-list-thumb {
        height: 180px!important;
        background-size: cover;
    }
    .card h4.blog-title {
        font-size: 16px;
        line-height: 25px;
    }
    .card-body.content-promotion {
        padding: 30px 10px;
    }
    .container.my-2.t1 .list-items {
        margin: 15px 5px;
    }
   .card.box-promotion {
        border: unset;
        filter: drop-shadow(2px 4px 6px #00000020);
    }
    .text-center.pagination {
        justify-content: center;
        padding: 35px 0;
    }
    a.btn-outline-info.active {
        background: #95C11E !important;
       
    }
    a.btn-outline-info {
        background: #ededed !important;
        border-radius: 5px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 3px;
        margin: 5px;
    }

    a.btn-outline-info.active:focus{display:none;}
</style>


<div class="col-sm-12 container" phpb-blocks-container>
    <div class="details-item">
        <?= $body ?>
   </div>
</div>


<div class="container my-2 t1" style=" display: grid;grid-template-columns: 25% 25% 25% 25%;padding: 0;">
    

        <?php

$lang = Helper::getPostsPromo();
// echo $lang;
$url = myUpload(); 

foreach ($lang as $value) {?>
 <div class="row list-items">
 <div class="col-md-12" style="padding:0;">
      <div class="card box-promotion">
        <div class="blog-post-list-thumb" style="background-image: url('<?php echo myupload().$value->thumbnail ;?>');"></div>
        <div class="card-body content-promotion">
          <h4 class="blog-title"><?php echo $value->title; ?></h4>
          <p class="card-text"><?php echo $value->excerpt; ?></p>
          <a href="<?php echo URL('en/blog').'/'.$value->slug?>">Read More</a>
        </div>
      </div>
          </div>
             </div>

   <?php } ?>    
    </div>
 
  
 


<script>
$(document).ready(function() {
  $('.t1').after('<div id="nav" class="text-center pagination"></div>');
  var rowsShown = 12;
  var rowsTotal = $('.t1 .row').length;
  var numPages = rowsTotal / rowsShown;
  for (i = 0; i < numPages; i++) {
    var pageNum = i + 1;
    $('#nav').append('<a href="#" class="btn-outline-info" rel="' + i + '">&emsp;' + pageNum + '&emsp;</a> ');
  }
  $('.t1 .row').hide();
  $('.t1 .row').slice(0, rowsShown).show();
  $('#nav a:first').addClass('active');
  $('#nav a').bind('click', function(e) {
  	e.preventDefault();
    $('#nav a').removeClass('active');
    $(this).addClass('active');
    var currPage = $(this).attr('rel');
    var startItem = currPage * rowsShown;
    var endItem = startItem + rowsShown;
    $('.t1 .row').css('opacity', '1').hide().slice(startItem, endItem).
    css('display', 'flex').animate({
      opacity: 1
    }, 300);
  });
});

</script>

<?php require(base_path().'/themes/giant/footer.php'); ?>