{!! Form::model($Milestones,['url' => 'admin/milestione/'.$Milestones->id, 'method'=>'PATCH']) !!}
<div class="form-group">
                    {{Form::label('title','Title')}}
                    {{Form::text('title',null,['class'=>'form-control'])}}
                </div>
                <div class="form-group">
                        {{Form::label('description','Description')}}
                        {{Form::textarea('description',null,['class'=>'form-control'])}}
                </div>
                <div class="form-group">
                                <label class="control-label mb-10">Thumbnail</label>
                                <a class="button secondary postfix image_selector2" style="float: right;" data-upateimage="feature_image2"><i class="fa fa-pencil" aria-hidden="true"></i> Change</a>
                                <div class="form-group">
                                <img class="thum-image" id="thum-image" height="150" src="{{ URL('assets/pagebuilder/images') }}/image.png"/>
                                <input type="hidden" id="feature_image2" name="thumbnail" value="{{ URL('assets/pagebuilder/images') }}/image.png" />
                        </div>
                                        </div>
                <div class="form-group">
                {!! Form::label('Publish') !!}
                                {!! Form::select('is_published', [1 => 'Publish', 0 => 'Draft'], null, ['class' => 'form-control']) !!}
                </div>
                <div class="form-group">
                {{ Form::button('<i class="fa fa-floppy-o" aria-hidden="true"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success mr-10'] )  }}
                </div>
{!! Form::close() !!}