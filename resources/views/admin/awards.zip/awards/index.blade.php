@extends('template')

@section('Title', 'Careers Management')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        Careers - list
                        <a href="{{ route('careers.create') }}" class="btn btn-sm btn-primary float-right">Add
                            New</a>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered mb-0">
                            <thead>
                            <tr>
                                <th scope="col" width="20">#</th>
                                <th scope="col">Title</th>
                                <th><i class="fa fa-globe" aria-hidden="true"></i> Language</th>
                                <th scope="col" width="200">Created By</th>
                                <th scope="col" width="129">Action</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($careers as $career)
                                <tr>
                                    <th scope="row">{{ $career->id }}</th>
                                    <td>{{ $career->title }}</td>
                                    <td>En</td>
                                    <td>{{ $career->user->name }}</td>
                                    <td>

                                        <a class="btn btn-sm btn-primary" href="{{ route('careers.show', $career->id) }}" target="_blank">View</a>
                                        <a href="{{ route('careers.edit', $career->id) }}" class="btn btn-sm btn-primary">Edit</a>
                                        {!! Form::open(['route' => ['careers.destroy', $career->id], 'method' => 'delete', 'style' => 'display:inline']) !!}
                                        {!! Form::submit('Delete',['class' => 'btn btn-sm btn-danger']) !!}
                                        {!! Form::close() !!}
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
